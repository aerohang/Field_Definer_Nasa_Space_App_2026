# FieldShift: Crop-rotation decision support with NASA data

**Challenge:** Help farmers explore crop-rotation strategies that strengthen soil health and adapt to changing conditions. The tool combines NASA Earth observations with local soil information, crop characteristics and farmer priorities.

## How FieldShift answers each part of the brief
| Brief asks for | FieldShift |
|---|---|
| NASA Earth observations | NASA POWER `T2M_MAX`, `PRECTOTCORR`, `GWETROOT` (root-zone soil wetness). Baseline (1991–2005) vs recent (2010–2024): warming, rain change, heat days, rainy-season onset, soil wetness |
| Shifting temperatures and rainfall, extreme heat | Crop fit is re-scored under both climates, and crops losing ground are flagged |
| Water shortages | Irrigation demand per rotation (mm/yr), three water-access levels, a "Save water" priority |
| Local soil information | Texture, organic matter, pH, drainage. Entered by the farmer, or filled in automatically from ISRIC SoilGrids |
| Crop characteristics | 18 crops: temperature range, heat threshold, water need, pH range, family, nitrogen fixing, residue, rooting depth, duration, winter hardiness, cover crop |
| Farmer priorities | 5 sliders: income, save water, soil health, climate resilience, stay close to what I grow |
| Rotation strategies, soil health | Beam search over 3-year, two-season rotations. Soil score rewards legumes, more families, residue, deep roots and cover crops, and penalizes repeating a family or leaving soil bare. Compared side by side with the farmer's current practice |
| Global | Growing windows are detected from each location's data (monsoon, temperate, two-rainy-season and Mediterranean climates). Demos: India ×3, USA, Kenya, Brazil |

## 3D field (new)
A light-themed 3D model of the farm (three.js, shipped in `static/vendor/`, no internet needed). Crops grow, ripen and are harvested month by month; rain, sun and clouds follow the climate data. Views: **Field**, **Under the soil** (roots, topsoil darkening as soil health improves, a blue soil-moisture band) and **From above**. "Compare with today" puts the current rotation beside the plan. Drag to turn it. Phones without WebGL get the flat drawing instead.

## Landing page (opens first)
A dark, sectioned home page: an animated field behind the headline, a "Plan a field" form that opens a real plan, six demo-farm cards computed live (temperature then vs now, rain change, soil score, suggested rotation), a water-savings estimator with a farm-size slider, a feature grid, the farmer card as a five-language carousel, and questions with honest answers. Every number on it comes from the engine; there are no invented testimonials or customer counts.

## Farmer mode
- **Language picked automatically by region:** the phone's own language first, then the region it is in (time zone and locale country: India → Hindi, Kenya/Tanzania/Uganda → Swahili, Brazil/Portugal → Portuguese, Spanish-speaking countries → Spanish), then the farm's region or GPS position. A manual choice in the top bar always wins and is remembered. India's other languages (Marathi, Punjabi, Telugu and more) are not translated yet, so Indian regions get Hindi.
- **Pictures instead of charts:** thermometers (then vs now), raindrops (each 💧 = 100 mm), suns for hot days, crop pictures for the 3-year plan, buckets (🪣) for pumped water, earthworms (🪱) for soil health, coins (🪙) for income, money icons (💸) for input cost, a traffic light (🚦) for risk.
- **🔊 Listen:** reads the whole plan aloud with the phone's built-in voice, for farmers who can't read.
- **Living field:** the plan plays as an animated field. Press play or drag the slider through 36 months: crops grow, ripen and are harvested, rain and heat follow that month's climate data, and the soil darkens as soil health improves. A marker moves along the calendar in step.
- **One question per screen:** setup is a 7-step guided flow with large buttons. Single-choice steps move on by themselves.
- **Tap a crop:** opens a sheet with its fit score, water need, input cost and labour.
- Motion is switched off for people who set "reduce motion" on their device.
- **Crop calendar:** the 3-year plan is drawn as a 12-month wall calendar per year, with each crop as a bar from sowing to harvest.
- **Field sensor readings (optional):** soil moisture, pH, salinity (EC) and rain-gauge totals. Readings override the satellite and map estimates: measured pH replaces the map pH, salinity marks down salt-sensitive crops, the rain gauge rescales satellite rainfall (limited to 60–160%), and soil moisture says whether to sow now. Three ways in: type them, load a logger CSV (detailed view), or let a device send them to the self-hosted server with `POST /api/sensor/<device key>` and JSON such as `{"moist": 23.5, "ph": 7.1, "ec": 0.8, "rain": 12}`. The key is shown by `GET /api/sensor` when logged in.
- **Affordable by design:** budget (little / some / enough) and labour (family only / can hire) change the plan. Each crop carries input-cost, labour and machinery traits. Every plan comes with no-machinery tips: hand or bullock sowing, renting from a Custom Hiring Centre or FPO instead of buying, saved seed, no stubble burning, green manure sown by hand.
- **Login:** a farmer, or a farm helper (Krishi Mitra) who manages a whole village. Phone number + 4-digit PIN. A "Try without account" demo for judges.
  - Self-hosted (`start.bat`): real accounts. PINs are hashed (never stored), there's a 15-minute lockout after 5 wrong tries, an HttpOnly session cookie, and data kept in `data/fieldshift.db` on your machine.
  - Public web page: no server, so accounts are saved only in that browser and the app says so. That isn't real security; use the self-hosted version for real farmer data.
- **📊 Detailed view** opens the full analysis for the same farm (for helpers and judges).

## Gaps in earlier projects, and how FieldShift closes them
| Gap | FieldShift |
|---|---|
| Built for big single-crop farms | Farm size, a pilot on 25% of the land, a family-food rule, smallholder crops |
| Pixels treated as exact; surface vs root zone confused | Trust panel (HIGH/MEDIUM/LOW), stated ~50 km grid, root-zone `GWETROOT` |
| No local ground truth | Soil test and "grew well / grew poorly for me" override the satellite estimate |
| Jargon, English only | Farmer card in EN/HI/ES/PT/SW plus a one-message SMS |
| Ignores markets, seed, privacy | Seed and market availability per crop; runs on the device; coordinates snapped to the 0.5° grid |
| Static demos | Baseline vs recent window that rolls forward each year; stress tests for hotter, drier and wetter futures |

## Run it
**Windows:** double-click `start.bat`. On first run it sets everything up (Python 3.9+ must be installed), then opens the app in your browser.

**Manual / Mac / Linux:**
```bash
pip install -r requirements.txt
python app.py        # http://localhost:5000, then the "Use real NASA data" tab → "Fetch live from NASA"
python -m pytest -q  # offline tests
```

## Files
- `static/engine.js`: crop library, growing-window detection, crop-fit model, rotation scoring and search, explanations (pure functions)
- `static/regions.js`: demo locations (illustrative climate values) and common current-practice rotations
- `static/index.html`: the app (Chart.js)
- `static/icons.js`: the icon set (drawn for this project, no emoji)
- `static/farmer.js`, `static/farmer-text.js`: farmer mode, login, voice, picture graphs (5 languages)
- `static/i18n.js`: farmer-view text in 5 languages (machine-drafted; needs native-speaker review)
- `app.py`: Flask backend with `/api/climate` (NASA POWER daily → monthly baseline/recent, exact heat days) and `/api/soil` (SoilGrids → texture, organic matter, pH)
- `test_app.py`: backend tests

## Limits
- The POWER grid is about 50 km, so this is regional climate, not field microclimate.
- Crop thresholds and relative values are general. Swap in local variety data and local prices.
- Scores are for screening options, not yield forecasts. Main-season and second-season crops can overlap by a few weeks in some locations.
- The live NASA and SoilGrids calls are written to the documented APIs but weren't reachable from the build environment. Run `/api/climate` and `/api/soil` once before demoing.

## Roadmap
SMAP soil moisture to check the water budget, HLS NDVI to confirm cover crops established, GPM IMERG for local onset, local price inputs, regional languages.
