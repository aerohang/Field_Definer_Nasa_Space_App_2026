@echo off
title FieldShift
cd /d "%~dp0"
echo.
echo  ===== FieldShift: rotation planning with NASA data =====
echo.

REM --- Find Python (python or the py launcher) ---
set "PY="
where python >nul 2>nul && python -c "import sys; sys.exit(0 if sys.version_info>=(3,9) else 1)" >nul 2>nul && set "PY=python"
if not defined PY ( where py >nul 2>nul && py -3 -c "import sys" >nul 2>nul && set "PY=py -3" )
if not defined PY (
  echo  Python 3.9 or newer was not found.
  echo  Install it from https://www.python.org/downloads/
  echo  and tick "Add python.exe to PATH" during setup. Then double-click start.bat again.
  echo.
  pause
  exit /b 1
)

REM --- First run only: create a private environment and install packages ---
if not exist ".venv\Scripts\python.exe" (
  echo  First-time setup: this takes about a minute...
  %PY% -m venv .venv || goto :fail
)
".venv\Scripts\python.exe" -m pip install --quiet --disable-pip-version-check -r requirements.txt || goto :fail

REM --- Open the browser once the server is up, then run the server ---
echo  Starting FieldShift at http://localhost:5000
echo  Keep this window open while you use the app. Close it to stop.
echo.
start "" cmd /c "timeout /t 4 /nobreak >nul & start http://localhost:5000"
".venv\Scripts\python.exe" app.py
pause
exit /b 0

:fail
echo.
echo  Setup failed. Check your internet connection and try again.
pause
exit /b 1
