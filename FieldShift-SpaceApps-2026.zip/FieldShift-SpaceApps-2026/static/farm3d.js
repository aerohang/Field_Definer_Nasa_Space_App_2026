/* FieldShift 3D field: a low-poly model of the farm, drawn with three.js r128 (MIT licence, vendored in vendor/).
   It shows what a flat picture can't: the crops above ground and, in the cut face of the soil block,
   the roots, the topsoil (darker = healthier) and the soil moisture (blue band, an estimate).
   Two blocks can stand side by side: what is grown today, and the suggested plan.
   The page falls back to the flat SVG scene when WebGL isn't available. */
(function(root){
"use strict";
const T=root.THREE;
const lerp=(a,b,k)=>a+(b-a)*k, clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const smooth=(a,b,x)=>{const k=clamp((x-a)/(b-a),0,1);return k*k*(3-2*k);};
const ease=x=>1-(1-x)*(1-x), DEG=Math.PI/180;
const esc=s=>String(s==null?"":s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function seeded(s){return()=>{s=(s*16807)%2147483647;return (s-1)/2147483646;};}

/* sizes, in scene units: one cultivated plot is W x D; the soil block is cut TOP + MID + BASE deep */
const W=6,D=6,MX=.45,MF=.45,MB=1.7,TOP=.45,MID=1.05,BASE=.6,ROWS=7,COLS=7,BASEY=.2,GAP=.9,PW=1.3,PH=1.18;
const BW=W+2*MX,BD=D+MF+MB,CZ=(MF-MB)/2,DEPTH=TOP+MID+BASE,CENTERZ=-.55;
const KEYS=["stem","tuft","bush","ear","head","leaves","dots","stubble"];
const VIEWS={field:{az:-28*DEG,el:24*DEG,y:.45,zoom:1},soil:{az:-13*DEG,el:7*DEG,y:-.4,zoom:.82},top:{az:0,el:74*DEG,y:.2,zoom:.9}};

/* How each crop is drawn. h = height at full growth; root = rooting depth; parts are scaled in as the crop grows.
   c = [young colour, ripe colour]; in/out = share of the season when a part appears or drops (flowers, bolls, ears). */
const G1="#63b548",STRAW="#d9b445",STEM=["#7fb24f","#b3a05c"];
const LOOK={
 maize:{h:1.4,root:1.05,parts:[{g:"stem",w:1.5,c:STEM},{g:"leaves",w:1.05,c:[G1,"#a8a24c"]},{g:"ear",w:.5,hf:.24,at:.42,ox:.1,c:["#a9cc55","#f0c62a"],in:[.55,.72]}]},
 rice:{h:.6,root:.4,flood:1,parts:[{g:"tuft",w:.62,c:["#78c64a","#cdb640"]},{g:"ear",w:.42,hf:.34,at:.74,tilt:.75,c:["#b0cc52","#e3b93a"],in:[.55,.7]}]},
 wheat:{h:.74,root:1,parts:[{g:"tuft",w:.6,hf:.86,c:[G1,STRAW]},{g:"ear",w:.42,hf:.3,at:.7,c:["#9cc650","#e4b22c"],in:[.5,.66]}]},
 barley:{h:.66,root:.7,parts:[{g:"tuft",w:.6,hf:.86,c:[G1,"#dcc05a"]},{g:"ear",w:.5,hf:.34,at:.68,c:["#a6c858","#ecc85a"],in:[.5,.66]}]},
 rye_cc:{h:.8,root:1.1,parts:[{g:"tuft",w:.7,c:[G1,"#86b54c"]},{g:"ear",w:.36,hf:.26,at:.76,c:["#9cc650","#c9bc5a"],in:[.7,.85]}]},
 sorghum:{h:1.3,root:1.2,parts:[{g:"stem",w:1.5,hf:.86,c:STEM},{g:"leaves",w:.95,hf:.8,c:[G1,"#a8a24c"]},{g:"head",w:.42,hf:.26,at:.8,c:["#bcc864","#a4432a"],in:[.5,.68]}]},
 millet:{h:1.22,root:1.2,parts:[{g:"stem",w:1.3,hf:.8,c:STEM},{g:"leaves",w:.85,hf:.72,c:[G1,"#a8a24c"]},{g:"ear",w:.62,hf:.36,at:.7,c:["#aec862","#8a6b3c"],in:[.5,.68]}]},
 soybean:{h:.52,root:.7,parts:[{g:"bush",w:.62,c:["#66b449","#b5a648"]}]},
 chickpea:{h:.4,root:1,parts:[{g:"bush",w:.56,c:["#82c25e","#bcae56"]}]},
 lentil:{h:.32,root:.55,parts:[{g:"bush",w:.52,c:["#88c463","#bbad5a"]}]},
 groundnut:{h:.3,root:.6,parts:[{g:"bush",w:.62,c:["#4f9e3c","#7c9a3a"]},{g:"dots",w:.56,c:["#f4d31c","#f4d31c"],in:[.3,.42],out:[.6,.72]}]},
 cowpea:{h:.38,root:1,parts:[{g:"bush",w:.68,c:["#5aaa45","#98a64a"]}]},
 pigeonpea:{h:1.15,root:1.3,parts:[{g:"stem",w:1.4,hf:.6,c:STEM},{g:"bush",w:.74,hf:.56,at:.44,c:["#5ca848","#809d46"]},{g:"dots",w:.7,hf:.56,at:.44,c:["#f5c91f","#f5c91f"],in:[.5,.62],out:[.82,.92]}]},
 cotton:{h:.92,root:1.25,parts:[{g:"stem",w:1.3,hf:.5,c:STEM},{g:"bush",w:.72,hf:.64,at:.34,c:["#4f9a3e","#6d8c3c"]},{g:"dots",w:.8,hf:.66,at:.33,c:["#ffffff","#ffffff"],in:[.62,.8]}]},
 mustard:{h:.86,root:1,parts:[{g:"stem",w:1.1,hf:.8,c:STEM},{g:"bush",w:.44,hf:.42,at:.1,c:[G1,"#9ea84a"]},{g:"head",w:.52,hf:.3,at:.7,c:["#f7da1f","#b8b262"],in:[.34,.48]}]},
 potato:{h:.42,root:.4,parts:[{g:"bush",w:.68,c:["#3f8f3a","#718f3c"]},{g:"dots",w:.6,c:["#f1e9ff","#f1e9ff"],in:[.4,.5],out:[.66,.76]}]},
 vetch_cc:{h:.26,root:.6,parts:[{g:"bush",w:.84,c:["#66b54c","#66b54c"]},{g:"dots",w:.78,c:["#9d72d4","#9d72d4"],in:[.45,.6]}]},
 sunn_cc:{h:1.2,root:1.25,parts:[{g:"stem",w:1.2,hf:.9,c:STEM},{g:"leaves",w:.72,hf:.82,c:["#6bbb4c","#6bbb4c"]},{g:"dots",w:.5,hf:.4,at:.62,c:["#f7d31e","#f7d31e"],in:[.55,.7]}]},
};
let C=null;
function prepare(){
  if(C) return;
  const c=h=>new T.Color(h);
  C={top0:c("#d2ad7c"),top1:c("#4a2e1b"),bed0:c("#c39866"),bed1:c("#402817"),gr0:c("#d3c27c"),gr1:c("#74ad49"),lf0:c("#8fa14a"),lf1:c("#3f8f3a"),
     l0:c("#fff4de"),l1:c("#ffdca6"),s0:c("#ffd84f"),s1:c("#ff8a3a"),c0:c("#ffffff"),c1:c("#b3bec7"),
     t0:c("#cfe7f5"),t1:c("#f8e4b4"),t2:c("#c3d0d8"),b0:c("#f2f8f3"),b1:c("#fdf7e6"),b2:c("#e9eef0"),k:c("#000000"),white:c("#ffffff"),straw:c("#c9b27a")};
  Object.values(LOOK).forEach(l=>l.parts.forEach(p=>{p.c0=c(p.c[0]);p.c1=c(p.c[1]);}));
}

let OK=null;
function supported(){
  if(OK!==null) return OK; OK=false;
  try{ if(T&&root.WebGLRenderingContext){const cv=document.createElement("canvas"),gl=cv.getContext("webgl")||cv.getContext("experimental-webgl"); OK=!!gl;
    if(gl){const x=gl.getExtension("WEBGL_lose_context"); if(x) x.loseContext();}} }catch(e){OK=false;}
  return OK;
}

/* ---------- geometry ---------- */
const M=(...ops)=>{const m=new T.Matrix4();ops.forEach(o=>m.multiply(o));return m;};
const tr=(x,y,z)=>new T.Matrix4().makeTranslation(x,y,z), rx=a=>new T.Matrix4().makeRotationX(a), ry=a=>new T.Matrix4().makeRotationY(a),
      rz=a=>new T.Matrix4().makeRotationZ(a), sc=(x,y,z)=>new T.Matrix4().makeScale(x,y,z);
function mergeGeo(list,round){
  const pos=[],nor=[],v=new T.Vector3(),n=new T.Vector3();
  list.forEach(([g,m])=>{const gg=g.index?g.toNonIndexed():g,a=gg.attributes.position;
    for(let i=0;i<a.count;i++){v.fromBufferAttribute(a,i);n.copy(v).normalize();if(m)v.applyMatrix4(m);pos.push(v.x,v.y,v.z);nor.push(n.x,n.y,n.z);}
    if(gg!==g)gg.dispose(); g.dispose();});
  const out=new T.BufferGeometry(); out.setAttribute("position",new T.Float32BufferAttribute(pos,3));
  if(round) out.setAttribute("normal",new T.Float32BufferAttribute(nor,3)); else out.computeVertexNormals();  /* round = soft shading for balls */
  return out;
}
function geos(){
  const G={},ico=(r,d)=>new T.IcosahedronGeometry(r,d),cone=(r,n)=>new T.ConeGeometry(r,1,n,1);
  G.box=new T.BoxGeometry(1,1,1); G.plane=new T.PlaneGeometry(1,1); G.ball=ico(1,2);
  G.ridge=new T.CylinderGeometry(.5,.5,1,6,1); G.ridge.rotateX(Math.PI/2);
  G.roof=new T.ConeGeometry(.84,.5,4,1); G.roof.rotateY(Math.PI/4);
  G.beam=new T.CylinderGeometry(.05,1.5,1,20,1,true);
  G.stem=new T.CylinderGeometry(.03,.05,1,5,1); G.stem.translate(0,.5,0);
  G.tuft=mergeGeo([0,1,2,3,4,5].map(i=>[cone(.075,4),M(ry(i*60*DEG+.3),rz((7+(i%3)*10)*DEG),sc(1,.74+(i%2)*.26,1),tr(0,.5,0))]));
  G.bush=mergeGeo([[ico(.5,0),M(tr(0,.42,0),sc(1,.84,1))]]);
  G.ear=mergeGeo([[new T.OctahedronGeometry(.5,0),M(tr(0,.5,0),sc(.36,1,.36))]]);
  G.head=mergeGeo([[ico(.5,0),M(tr(0,.5,0),sc(.62,1,.62))]]);
  G.leaves=mergeGeo([0,1,2,3,4,5].map(i=>[cone(.1,3),M(tr(0,.2+i*.115,0),ry(i*137*DEG),rz((50+(i%2)*16)*DEG),sc(1,.52,.35),tr(0,.5,0))]));
  G.dots=mergeGeo([[.32,.62,.1],[-.28,.55,.2],[.05,.82,-.25],[-.1,.72,.3],[.3,.4,-.25],[-.33,.38,-.15],[0,.92,.05],[.12,.5,.36]].map(p=>[ico(.085,0),tr(p[0],p[1],p[2])]));
  const st=h=>new T.CylinderGeometry(.018,.024,h,4,1);
  G.stubble=mergeGeo([[st(.16),M(tr(-.07,.08,.03),rz(.2))],[st(.14),tr(.06,.07,-.05)],[st(.15),M(tr(.02,.075,.08),rx(.25))]]);
  const down=(r,len,y,a)=>[cone(r,4),M(tr(0,y,0),rz(a),rx(Math.PI),sc(1,len,1),tr(0,.5,0))];
  G.root=mergeGeo([down(.055,1,0,0),down(.035,.5,-.16,42*DEG),down(.035,.46,-.3,-40*DEG),down(.03,.3,-.5,30*DEG)]);
  G.cloud=mergeGeo([[0,0,0,1],[.95,-.12,.1,.74],[-.9,-.14,-.1,.7],[.3,.28,-.35,.6],[-.35,.22,.3,.56]].map(c=>[ico(c[3],2),M(tr(c[0],c[1],c[2]),sc(1,.7,1))]),true);
  G.canopy=mergeGeo([[0,.3,0,.5],[.3,.1,.15,.36],[-.28,.12,-.12,.38]].map(c=>[ico(c[3],0),tr(c[0],c[1],c[2])]));
  return G;
}

/* Root-zone moisture for 36 months, 0..1. Uses NASA GWETROOT when the climate record has it; otherwise a simple
   monthly water balance (rain in, evaporation out). Irrigation adds to it. This is a display estimate. */
function moistureSeries(d,spans){
  const out=new Array(36),cap=220; let S=cap*.3;
  for(let pass=0;pass<2;pass++) for(let k=0;k<36;k++){
    const m=(d.start-1+k)%12; let irr=0; for(const sp of spans) if(k>=sp.s&&k<sp.s+sp.len) irr+=(sp.irr||0)/sp.len;
    if(d.wet&&d.wet[m]!=null){out[k]=clamp(d.wet[m]+irr/160,0,1);continue;}
    const pet=Math.max(25,(d.tmax[m]-6)*5.2); S=clamp(S+d.rain[m]*.8+irr-pet,0,cap);
    out[k]=irr>15?Math.max(S/cap,clamp(.3+irr/220,0,.85)):S/cap; }   /* an irrigated crop keeps its root zone moist */
  return out;
}

/* ---------- one block of land ---------- */
class Plot{
  constructor(f,key){
    this.f=f; this.key=key; this.xT=0; this.spans=[]; this.moistS=new Array(36).fill(.3); this.soilFrom=50; this.soilTo=50;
    const G=f.G,m=f.m,g=this.group=new T.Group(); f.scene.add(g);
    const box=(mat,sx,sy,sz,x,y,z,rec,cast)=>{const b=new T.Mesh(G.box,mat);b.scale.set(sx,sy,sz);b.position.set(x,y,z);b.receiveShadow=!!rec;b.castShadow=!!cast;g.add(b);return b;};
    this.topMat=m("MeshLambertMaterial",{color:0xc9a06c}); this.bedMat=m("MeshLambertMaterial",{color:0xa97c50});
    this.grassMat=m("MeshLambertMaterial",{color:0x8fb85a}); this.leafMat=m("MeshLambertMaterial",{color:0x4f9a3e});
    box(this.topMat,BW,TOP,BD,0,-TOP/2,CZ); box(f.midMat,BW,MID,BD,0,-TOP-MID/2,CZ); box(f.baseMat,BW,BASE,BD,0,-TOP-MID-BASE/2,CZ);
    box(this.grassMat,BW,.07,BD,0,.035,CZ,true);
    box(this.bedMat,W+.16,.1,D+.16,0,.1,0,true);
    for(let r=0;r<ROWS;r++){const rd=new T.Mesh(G.ridge,this.bedMat);rd.scale.set(.5,.2,D-.1);rd.position.set(-W/2+(r+.5)*W/ROWS,.15,0);rd.receiveShadow=true;g.add(rd);}
    this.moistMat=m("MeshBasicMaterial",{color:0x1f9af0,transparent:true,opacity:.56,depthWrite:false});
    this.moist=box(this.moistMat,BW+.04,1,BD+.04,0,0,CZ);
    this.floodMat=m("MeshLambertMaterial",{color:0x8fd4f5,transparent:true,opacity:.6,emissive:0x1a3f55});
    this.flood=box(this.floodMat,W+.1,.05,D+.1,0,.215,0,true); this.flood.visible=false;
    this.channel=box(f.waterMat,W+.16,.06,.26,0,.1,-D/2-.4); this.channel.visible=false;
    /* hut, tree and hand pump on the back margin */
    const hx=W/2-1.15,hz=-D/2-.98;
    box(f.wallMat,1,.62,.8,hx,.38,hz,true,true); box(f.darkMat,.22,.36,.04,hx-.18,.25,hz+.41);
    const rf=new T.Mesh(G.roof,f.roofMat); rf.position.set(hx,.93,hz); rf.castShadow=true; g.add(rf);
    const tx=-W/2+.95,tz=-D/2-1;
    const trunk=new T.Mesh(G.stem,f.darkMat); trunk.scale.set(2.4,.8,2.4); trunk.position.set(tx,.07,tz); trunk.castShadow=true; g.add(trunk);
    const can=new T.Mesh(G.canopy,this.leafMat); can.position.set(tx,.78,tz); can.scale.setScalar(1.15); can.castShadow=true; g.add(can);
    box(f.pumpMat,.12,.5,.12,-.2,.32,-D/2-.4,false,true); box(f.pumpMat,.34,.07,.07,-.06,.5,-D/2-.4,false,true);
    /* soft shadow under the block, and an unseen box for taps */
    const blob=new T.Mesh(G.plane,f.blobMat); blob.rotation.x=-Math.PI/2; blob.scale.set(BW*1.6,BD*1.5,1); blob.position.set(0,-DEPTH-.45,CZ); g.add(blob);
    this.hit=new T.Mesh(G.box,f.hitMat); this.hit.scale.set(BW,DEPTH+2,BD); this.hit.position.set(0,(2-DEPTH)/2,CZ); this.hit.userData.key=key; g.add(this.hit);
    /* plants */
    const rnd=seeded(key==="plan"?7:13); this.N=ROWS*COLS; this.plants=[];
    for(let r=0;r<ROWS;r++) for(let c=0;c<COLS;c++)
      this.plants.push({x:-W/2+(r+.5)*W/ROWS+(rnd()-.5)*.08,z:-D/2+(c+.5)*D/COLS+(rnd()-.5)*.1,ry:rnd()*6.28,s:.86+rnd()*.28,ph:rnd()*6.28,dp:(rnd()-.5)*.05});
    this.inst={};
    KEYS.forEach(k=>{const im=new T.InstancedMesh(G[k],f.plantMat,this.N); im.castShadow=k!=="stubble"&&k!=="dots"; im.frustumCulled=false; im.visible=false;
      for(let i=0;i<this.N;i++){im.setMatrixAt(i,f.zero);im.setColorAt(i,k==="stubble"?C.straw:C.white);} g.add(im); this.inst[k]=im;});
    /* roots, drawn on the cut faces of the block */
    this.rootSlots=[];
    for(let r=0;r<ROWS;r++) this.rootSlots.push({x:-W/2+(r+.5)*W/ROWS,z:D/2+MF+.045,ry:0,s:.8+rnd()*.4});
    for(let c=0;c<COLS;c++){const z=-D/2+(c+.5)*D/COLS; this.rootSlots.push({x:-BW/2-.045,z,ry:Math.PI/2,s:.8+rnd()*.4},{x:BW/2+.045,z,ry:Math.PI/2,s:.8+rnd()*.4});}
    this.roots=new T.InstancedMesh(G.root,f.rootMat,this.rootSlots.length); this.roots.frustumCulled=false; this.roots.visible=false;
    for(let i=0;i<this.rootSlots.length;i++) this.roots.setMatrixAt(i,f.zero);
    g.add(this.roots);
  }
  setData(pd,moist){this.spans=pd.spans||[];this.soilFrom=pd.soilFrom;this.soilTo=pd.soilTo;this.moistS=moist;this.labelText=pd.label;this.cur=undefined;this.stubNow=-1;}
  spanAt(t){for(let i=this.spans.length-1;i>=0;i--){const s=this.spans[i];if(t>=s.s&&t<s.s+s.len)return s;}return null;}
  moistAt(t){const i=Math.min(35,Math.floor(t)),j=Math.min(35,i+1);return lerp(this.moistS[i],this.moistS[j],t-i);}
  update(t,env,time){
    const f=this.f,sp=this.spanAt(t),look=sp&&!sp.fallow?(LOOK[sp.id]||LOOK.soybean):null,p=sp?(t-sp.s)/sp.len:0;
    const h=clamp(lerp(this.soilFrom,this.soilTo,t/36)/100,0,1),m=this.moistAt(t);
    this.topMat.color.copy(C.top0).lerp(C.top1,h).multiplyScalar(lerp(1,.9,m));
    this.bedMat.color.copy(C.bed0).lerp(C.bed1,h).multiplyScalar(lerp(1.04,.84,m));
    this.grassMat.color.copy(C.gr0).lerp(C.gr1,env.green); this.leafMat.color.copy(C.lf0).lerp(C.lf1,env.green);
    const lv=m*(TOP+MID-.14); this.moist.visible=lv>.05; if(this.moist.visible){this.moist.scale.y=lv;this.moist.position.y=-(TOP+MID)+lv/2;}
    const fl=look&&look.flood?smooth(0,.07,p)*(1-smooth(.8,.9,p)):0; this.flood.visible=fl>.02; this.floodMat.opacity=.62*fl;
    this.channel.visible=!!(look&&sp.irr>15&&p<.88);
    const N=this.N,dm=f.dummy,col=f.tmpCol,hv=look?1-smooth(.955,.995,p):0;
    for(const k of KEYS) this.inst[k].visible=false;
    if(look&&hv>.01){
      for(const part of look.parts){
        const mesh=this.inst[part.g],hf=part.hf||1; mesh.visible=true;
        for(let i=0;i<N;i++){
          const pl=this.plants[i],pp=clamp(p+pl.dp,0,1),grow=.08+.92*ease(Math.min(1,pp/.72)),ripe=smooth(.6,.92,pp);
          const kin=part.in?smooth(part.in[0],part.in[1],pp):1,kout=part.out?1-smooth(part.out[0],part.out[1],pp):1;
          const k=grow*kin*kout*hv*pl.s,H=look.h*PH*grow*pl.s,sw=Math.sin(time*1.7+pl.ph)*env.wind*(.02+.05*grow);
          dm.position.set(pl.x+(part.ox||0)*grow,BASEY+(part.at||0)*H,pl.z);
          dm.rotation.set(sw*.6,pl.ry,sw+(part.tilt||0)*kin);
          dm.scale.set(part.w*PW*k,look.h*PH*hf*k,part.w*PW*k); dm.updateMatrix(); mesh.setMatrixAt(i,dm.matrix);
          col.copy(part.c0).lerp(part.c1,ripe); mesh.setColorAt(i,col);
        }
        mesh.instanceMatrix.needsUpdate=true; mesh.instanceColor.needsUpdate=true;
      }
    }
    const stub=look?smooth(.955,.995,p):1,sm=this.inst.stubble;
    if(stub>.02){ sm.visible=true;
      if(Math.abs(stub-this.stubNow)>.01){ this.stubNow=stub;
        for(let i=0;i<N;i++){const pl=this.plants[i];dm.position.set(pl.x,BASEY-.02,pl.z);dm.rotation.set(0,pl.ry,0);dm.scale.setScalar(stub*(.9+pl.s*.6));dm.updateMatrix();sm.setMatrixAt(i,dm.matrix);}
        sm.instanceMatrix.needsUpdate=true; } }
    const rm=this.roots;
    if(look&&hv>.01){ rm.visible=true; const g=ease(Math.min(1,clamp(p,0,1)/.6))*hv,depth=look.root||.7;
      for(let i=0;i<this.rootSlots.length;i++){const s=this.rootSlots[i];dm.position.set(s.x,-.02,s.z);dm.rotation.set(0,s.ry,0);
        dm.scale.set(.9*s.s*(.4+.6*g),Math.max(.001,depth*g*s.s),.35);dm.updateMatrix();rm.setMatrixAt(i,dm.matrix);}
      rm.instanceMatrix.needsUpdate=true; } else rm.visible=false;
  }
}

/* ---------- the scene ---------- */
class Farm3D{
  constructor(el,o){
    prepare();
    this.el=el; this.o=o||{}; this.t=0; this.time=0; this.dirty=true; this.hidden=false; this.mats=[]; this.slow=0; this.quality=2; this.view="field"; this.autoAt=0;
    this.w=Math.max(2,el.clientWidth); this.h=Math.max(2,el.clientHeight);
    const r=this.renderer=new T.WebGLRenderer({antialias:true,alpha:true});
    this.pr=Math.min(root.devicePixelRatio||1,this.o.pixelRatio||2); r.setPixelRatio(this.pr); r.setSize(this.w,this.h,false); r.setClearColor(0xffffff,0);
    r.shadowMap.enabled=true; r.shadowMap.type=T.PCFSoftShadowMap;
    const cv=this.canvas=r.domElement; cv.className="f3-canvas"; el.appendChild(cv);
    this.labelBox=document.createElement("div"); this.labelBox.className="f3-labels"; el.appendChild(this.labelBox); el.classList.add("f3-on");
    this.G=geos(); const m=this.m=(cls,opt)=>{const x=new T[cls](opt);this.mats.push(x);return x;};
    this.dummy=new T.Object3D(); this.tmpCol=new T.Color(); this.zero=new T.Matrix4().makeScale(0,0,0); this.v1=new T.Vector3(); this.v2=new T.Vector3(); this.up=new T.Vector3(0,1,0);
    const scn=this.scene=new T.Scene();
    this.camera=new T.PerspectiveCamera(30,this.w/this.h,.5,200);
    this.hemi=new T.HemisphereLight(0xffffff,0xcdb894,.8); scn.add(this.hemi);
    const L=this.sun=new T.DirectionalLight(0xfff1d6,.78); L.castShadow=true; L.shadow.mapSize.set(1024,1024);
    const shc=L.shadow.camera; shc.left=-13;shc.right=13;shc.top=12;shc.bottom=-12;shc.near=1;shc.far=60; L.shadow.bias=-.0015; L.shadow.normalBias=.03;
    L.position.set(-10,15,9); L.target.position.set(0,0,-.5); scn.add(L); scn.add(L.target);
    /* shared materials */
    this.plantMat=m("MeshLambertMaterial",{color:0xffffff}); this.rootMat=m("MeshLambertMaterial",{color:0xf6ead0});
    this.midMat=m("MeshLambertMaterial",{color:0xb98152}); this.baseMat=m("MeshLambertMaterial",{color:0x968675});
    this.waterMat=m("MeshLambertMaterial",{color:0x4aa3d8}); this.wallMat=m("MeshLambertMaterial",{color:0xf1e3c4});
    this.roofMat=m("MeshLambertMaterial",{color:0xb8623a}); this.darkMat=m("MeshLambertMaterial",{color:0x6b4a2e}); this.pumpMat=m("MeshLambertMaterial",{color:0x5c7f93});
    this.hitMat=m("MeshBasicMaterial",{visible:false});
    const bc=document.createElement("canvas"); bc.width=bc.height=128; const bx=bc.getContext("2d"),gr=bx.createRadialGradient(64,64,6,64,64,64);
    gr.addColorStop(0,"rgba(70,52,28,.5)"); gr.addColorStop(1,"rgba(70,52,28,0)"); bx.fillStyle=gr; bx.fillRect(0,0,128,128);
    this.blobTex=new T.CanvasTexture(bc); this.blobMat=m("MeshBasicMaterial",{map:this.blobTex,transparent:true,depthWrite:false});
    /* sky: sun, clouds, rain */
    this.sunMat=m("MeshBasicMaterial",{color:0xffd24d}); this.haloMat=m("MeshBasicMaterial",{color:0xffe08a,transparent:true,opacity:.22,depthWrite:false});
    this.sunBall=new T.Mesh(this.G.ball,this.sunMat); const halo=new T.Mesh(this.G.ball,this.haloMat); halo.scale.setScalar(1.7); this.sunBall.add(halo); scn.add(this.sunBall);
    this.cloudMat=m("MeshLambertMaterial",{color:0xffffff,emissive:0x565b60});
    this.clouds=[[-.8,6.1,-3.2,1.25],[.25,6.9,-4.6,1],[.85,6.2,-1.6,1.1],[-.2,6.6,.6,.85],[.6,7.1,2.2,.9]].map((c,i)=>{const cm=new T.Mesh(this.G.cloud,this.cloudMat);cm.userData={fx:c[0],y:c[1],z:c[2],s:c[3],i};scn.add(cm);return cm;});
    this.RN=260; const rr=seeded(3); this.rainSeed=[]; for(let i=0;i<this.RN;i++) this.rainSeed.push([rr(),rr()*8,rr()]);
    this.rainPos=new Float32Array(this.RN*6); this.rainGeo=new T.BufferGeometry(); this.rainGeo.setAttribute("position",new T.BufferAttribute(this.rainPos,3));
    this.rainMat=m("LineBasicMaterial",{color:0x4f93c9,transparent:true,opacity:.6}); this.rain=new T.LineSegments(this.rainGeo,this.rainMat); this.rain.frustumCulled=false; this.rain.visible=false; scn.add(this.rain);
    /* NASA satellite and its scan beam (landing page only) */
    if(this.o.satellite){
      const g=this.sat=new T.Group(),body=m("MeshLambertMaterial",{color:0xdfe3e8}),pan=m("MeshLambertMaterial",{color:0x3b6ea8});
      const part=(mat,sx,sy,sz,x)=>{const b=new T.Mesh(this.G.box,mat);b.scale.set(sx,sy,sz);b.position.x=x;g.add(b);};
      part(body,.34,.26,.26,0); part(pan,.62,.03,.3,-.52); part(pan,.62,.03,.3,.52); g.scale.setScalar(1.7); scn.add(g);
      this.beamMat=m("MeshBasicMaterial",{color:0x7cc4ee,transparent:true,opacity:.14,side:T.DoubleSide,depthWrite:false});
      this.beam=new T.Mesh(this.G.beam,this.beamMat); scn.add(this.beam);
    }
    this.plots={today:new Plot(this,"today"),plan:new Plot(this,"plan")};
    const lab=c=>{const d=document.createElement("div");d.className="f3-label "+c;d.style.display="none";this.labelBox.appendChild(d);return d;};
    this.lab={today:lab("f3-plot"),plan:lab("f3-plot is-plan"),soil:lab("f3-call"),moist:lab("f3-call f3-blue")};
    this.ray=new T.Raycaster(); this.ptr=new T.Vector2();
    this.setCompare(false,false); this.setView("field",false);
    if(!this.o.static) this.listen();
  }
  listen(){
    const cv=this.canvas; cv.style.touchAction="pan-y";
    const touched=()=>{this.auto=false;this.autoAt=performance.now()+9000;};
    cv.addEventListener("pointerdown",e=>{this.drag={x:e.clientX,y:e.clientY,az:this.azT,el:this.elT,moved:0,t:performance.now(),id:e.pointerId,mouse:e.pointerType==="mouse"};
      try{cv.setPointerCapture(e.pointerId);}catch(_){} touched(); if(this.o.onTouch) this.o.onTouch();});
    cv.addEventListener("pointermove",e=>{const d=this.drag; if(!d||d.id!==e.pointerId) return; const dx=e.clientX-d.x,dy=e.clientY-d.y; d.moved=Math.max(d.moved,Math.abs(dx)+Math.abs(dy));
      this.azT=d.az-dx*.008; if(d.mouse) this.elT=clamp(d.el+dy*.006,2*DEG,82*DEG); this.dirty=true;});
    const end=e=>{const d=this.drag; if(!d) return; this.drag=null; touched(); if(e.type==="pointerup"&&d.moved<7&&performance.now()-d.t<450) this.tap(e);};
    cv.addEventListener("pointerup",end); cv.addEventListener("pointercancel",end);
    if(root.ResizeObserver){this.ro=new ResizeObserver(()=>this.resize()); this.ro.observe(this.el);}
    if(root.IntersectionObserver){this.io=new IntersectionObserver(en=>{this.hidden=!en[0].isIntersecting;if(!this.hidden)this.dirty=true;},{threshold:.01}); this.io.observe(this.el);}
    const loop=now=>{ this.raf=requestAnimationFrame(loop);
      if(this.hidden||document.hidden){this.last=now;return;}
      const dt=Math.min(.08,(now-(this.last||now))/1000); this.last=now;
      let active=false; if(this.o.onFrame) active=this.o.onFrame(dt,now)===true;
      if(this.o.autoRotate&&!this.auto&&!this.drag&&this.view==="field"&&now>this.autoAt){this.auto=true;this.autoBase=this.azT;this.autoT0=this.time;}
      const moving=this.ease(dt);
      if(active||moving||this.dirty||this.drag||this.auto){this.time+=dt;this.draw();this.dirty=false;this.perf(dt);}
    };
    this.raf=requestAnimationFrame(loop);
  }
  perf(dt){ /* step quality down on phones that can't keep up: first shadows, then resolution */
    if(root.F3_KEEP_QUALITY) return;
    this.slow=dt>.045?this.slow+1:Math.max(0,this.slow-1);
    if(this.slow>45){ this.slow=0;
      if(this.quality===2){this.quality=1;this.sun.castShadow=false;}
      else if(this.quality===1){this.quality=0;this.pr=1;this.renderer.setPixelRatio(1);this.renderer.setSize(this.w,this.h,false);} }
  }
  resize(){const w=this.el.clientWidth,h=this.el.clientHeight; if(w<2||h<2||(w===this.w&&h===this.h)) return; this.w=w;this.h=h;
    this.renderer.setSize(w,h,false); this.camera.aspect=w/h; this.camera.updateProjectionMatrix(); this.fit(true); this.dirty=true;}
  fit(snap){const vf=this.camera.fov*DEG/2,hf=Math.atan(Math.tan(vf)*this.camera.aspect),a=Math.min(vf,hf);
    this.distT=(this.RT||6)/Math.sin(a)*(this.zoomT||1); if(snap||this.dist==null) this.dist=this.distT;}
  setData(d){this.d=d; for(const k of ["today","plan"]) this.plots[k].setData(d.plots[k],moistureSeries(d,d.plots[k].spans));
    this.lab.soil.textContent=d.text.soil; this.lab.moist.textContent=d.text.moist; this.dirty=true;}
  setTime(t){this.t=clamp(t,0,35.999); this.dirty=true;}
  setView(name,animate){const v=VIEWS[name]||VIEWS.field; this.view=VIEWS[name]?name:"field"; this.azT=v.az; this.elT=v.el; this.cyT=v.y; this.zoomT=v.zoom;
    this.auto=!!this.o.autoRotate&&this.view==="field"; this.autoBase=v.az; this.autoT0=this.time;
    if(!animate){this.az=this.azT;this.elv=this.elT;this.cy=this.cyT;} this.fit(!animate); this.dirty=true;}
  setCompare(on,animate){this.compare=!!on; this.hwT=on?BW+GAP/2:BW/2; this.RT=on?8.9:6.5;
    this.plots.today.xT=-(BW+GAP)/2; this.plots.plan.xT=on?(BW+GAP)/2:0; this.plots.today.group.visible=this.compare;
    if(!animate){this.hw=this.hwT; for(const k of ["today","plan"]) this.plots[k].group.position.x=this.plots[k].xT;}
    else if(on) this.plots.today.group.position.x=this.plots.today.xT;
    this.fit(!animate); this.dirty=true;}
  ease(dt){
    const k=1-Math.pow(.001,dt); let mv=false;
    const go=(p,q)=>{const d=this[q]-this[p]; if(Math.abs(d)>1e-3){this[p]+=d*k;mv=true;} else this[p]=this[q];};
    if(this.auto&&!this.drag) this.azT=this.autoBase+Math.sin((this.time-this.autoT0)*.22)*.36;
    go("az","azT"); go("elv","elT"); go("cy","cyT"); go("dist","distT"); go("hw","hwT");
    for(const key of ["today","plan"]){const p=this.plots[key],d=p.xT-p.group.position.x; if(Math.abs(d)>1e-3){p.group.position.x+=d*k;mv=true;} else p.group.position.x=p.xT;}
    return mv;
  }
  place(el,x,y,z){const v=this.v1.set(x,y,z).project(this.camera); if(v.z>1||v.z<-1){el.style.display="none";return;}
    el.style.display=""; el.style.transform="translate(-50%,-50%) translate("+((v.x+1)/2*this.w).toFixed(1)+"px,"+((1-v.y)/2*this.h).toFixed(1)+"px)";}
  draw(){
    const d=this.d; if(!d) return;
    const t=this.t,mi=Math.floor(t)%12,cm=(d.start-1+mi)%12,nm=(cm+1)%12,fr=t-Math.floor(t);
    const rain=lerp(d.rain[cm],d.rain[nm],fr),temp=lerp(d.tmax[cm],d.tmax[nm],fr);
    const wet=clamp(rain/170,0,1),hot=clamp((temp-22)/20,0,1),rainAmt=clamp((rain-45)/110,0,1);
    const pm=this.plots.plan.moistAt(t),env={wet,hot,rainAmt,green:clamp(.12+.88*Math.max(pm,wet*.85),0,1),wind:.5+rainAmt*1.3};
    const ce=Math.cos(this.elv),hw=this.hw;
    this.camera.position.set(this.dist*ce*Math.sin(this.az),this.cy+this.dist*Math.sin(this.elv),CENTERZ+this.dist*ce*Math.cos(this.az));
    this.camera.lookAt(0,this.cy,CENTERZ); this.camera.updateMatrixWorld();
    this.sun.intensity=lerp(.8,.42,wet); this.sun.color.copy(C.l0).lerp(C.l1,hot); this.hemi.intensity=lerp(.8,.92,wet);
    const sky=lerp(.72,.94,clamp((hw-BW/2)/(BW/2+GAP/2),0,1));
    this.sunBall.position.set(-(hw+1.2),6.2*sky,-5.6); this.sunBall.scale.setScalar(Math.max(.01,lerp(.62,1.1,hot)*(1-.55*wet))); this.sunMat.color.copy(C.s0).lerp(C.s1,hot);
    this.cloudMat.color.copy(C.c0).lerp(C.c1,rainAmt);
    const above=1-smooth(48*DEG,62*DEG,this.elv);   /* clouds step aside when looking straight down */
    for(const c of this.clouds){const u=c.userData,cs=u.s*(.15+wet)*above; c.visible=wet>.05&&above>.02; c.position.set(u.fx*(hw+.6)+Math.sin(this.time*.13+u.i*2.1)*.7,u.y*sky,u.z); c.scale.set(cs*sky,cs*sky,cs*sky);}
    const n=Math.floor(this.RN*rainAmt); this.rain.visible=n>0;
    if(n>0){const a=this.rainPos;
      for(let i=0;i<n;i++){const s=this.rainSeed[i],x=lerp(-hw-.8,hw+.8,s[0]),z=lerp(-5.2,3.8,s[2]); let y=(s[1]-this.time*9)%8; if(y<0)y+=8; y+=.1; const j=i*6;
        a[j]=x;a[j+1]=y;a[j+2]=z;a[j+3]=x+.06;a[j+4]=y+.45;a[j+5]=z;}
      this.rainGeo.attributes.position.needsUpdate=true; this.rainGeo.setDrawRange(0,n*2); this.rainMat.opacity=.35+.4*rainAmt;}
    const top=C.k.copy(C.t0).lerp(C.t1,hot).lerp(C.t2,wet*.8).getHexString(),bot=C.k.copy(C.b0).lerp(C.b1,hot).lerp(C.b2,wet*.8).getHexString();
    if(top+bot!==this.skyKey){this.skyKey=top+bot; if(this.o.onSky) this.o.onSky("#"+top,"#"+bot); else this.el.style.background="linear-gradient(#"+top+",#"+bot+")";}
    this.plots.plan.update(t,env,this.time); if(this.compare) this.plots.today.update(t,env,this.time);
    if(this.sat){const a=this.time*.32; this.sat.position.set(Math.cos(a)*(hw+1.5),6.9,-1+Math.sin(a)*4.2); this.sat.lookAt(0,0,0);
      const v1=this.v1.set(Math.sin(this.time*.8)*(hw-.6),.3,Math.cos(this.time*.55)*2.4),v2=this.v2.copy(this.sat.position).sub(v1),len=v2.length();
      this.beam.position.copy(v1).addScaledVector(v2,.5); this.beam.scale.set(1,len,1); this.beam.quaternion.setFromUnitVectors(this.up,v2.normalize());}
    /* labels */
    for(const key of ["today","plan"]){const p=this.plots[key],lb=this.lab[key];
      if(!this.compare){lb.style.display="none";continue;}
      const sp=p.spanAt(t),id=sp?sp.id:"fallow";
      if(p.cur!==id||p.curLabel!==p.labelText){p.cur=id;p.curLabel=p.labelText;lb.innerHTML="<b>"+esc(p.labelText)+"</b><span>"+esc(d.names[id]||id)+"</span>";}
      this.place(lb,p.group.position.x,2.9,-D/2-.9); }
    const so=this.view==="soil",px=this.plots.plan.group.position.x;
    this.lab.soil.classList.toggle("on",so); this.lab.moist.classList.toggle("on",so&&this.plots.plan.moist.visible);
    if(so){this.place(this.lab.soil,px-1.9,-TOP/2,D/2+MF); this.place(this.lab.moist,px+1.7,-(TOP+MID)+.26,D/2+MF);}
    else{this.lab.soil.style.display="none";this.lab.moist.style.display="none";}
    this.renderer.render(this.scene,this.camera);
  }
  renderNow(){this.ease(10); this.draw();}
  invalidate(){this.dirty=true;}
  tap(e){ if(!this.o.onTap) return; const b=this.canvas.getBoundingClientRect();
    this.ptr.set((e.clientX-b.left)/b.width*2-1,-((e.clientY-b.top)/b.height)*2+1); this.ray.setFromCamera(this.ptr,this.camera);
    const hits=this.ray.intersectObjects(this.compare?[this.plots.plan.hit,this.plots.today.hit]:[this.plots.plan.hit],false);
    if(hits.length) this.o.onTap(hits[0].object.userData.key); }
  dispose(){
    cancelAnimationFrame(this.raf); if(this.ro) this.ro.disconnect(); if(this.io) this.io.disconnect();
    Object.values(this.G).forEach(g=>g.dispose()); this.rainGeo.dispose(); this.mats.forEach(x=>x.dispose()); this.blobTex.dispose();
    try{this.renderer.dispose(); this.renderer.forceContextLoss();}catch(e){}
    if(this.canvas.parentNode) this.canvas.parentNode.removeChild(this.canvas);
    if(this.labelBox.parentNode) this.labelBox.parentNode.removeChild(this.labelBox);
    this.el.classList.remove("f3-on");
  }
}
Farm3D.supported=supported;
/* Render still pictures of several farms with one off-screen scene. list = [{data, t}]; each(i, dataUrl). */
Farm3D.snapshots=function(list,w,h,each,done){
  if(!supported()){if(done)done(false);return;}
  const box=document.createElement("div"); box.style.cssText="position:fixed;left:-9999px;top:0;width:"+w+"px;height:"+h+"px;pointer-events:none"; document.body.appendChild(box);
  let f; try{f=new Farm3D(box,{static:true,pixelRatio:2});}catch(e){box.remove();if(done)done(false);return;}
  let i=0; const step=()=>{
    if(i>=list.length){f.dispose();box.remove();if(done)done(true);return;}
    try{f.setData(list[i].data);f.setCompare(false,false);f.setView("field",false);f.setTime(list[i].t);f.renderNow();each(i,f.canvas.toDataURL("image/png"));}catch(e){}
    i++; setTimeout(step,30); };
  step();
};
root.Farm3D=Farm3D;
})(this);
