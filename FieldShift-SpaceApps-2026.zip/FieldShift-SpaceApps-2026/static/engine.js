/* FieldShift rotation engine — pure functions, shared by the web app and tests. */
(function (root) {
const DIM=[31,28,31,30,31,30,31,31,30,31,30,31];
const MON=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const SD=2.2; // assumed day-to-day spread of Tmax around the monthly mean (°C)

/* Crop traits: general agronomic values (replace with local variety data before field use).
   topt = ideal monthly-mean daytime high (°C); tstress = heat-stress threshold; water = seasonal need [min,max] mm;
   res = residue returned to soil (0-1); deep = deep-rooted; val = relative market value (0-1); hardy = survives winter dormancy;
   wl = tolerates waterlogging; sandy = fit multiplier on sandy soil.
   salt = salt tolerance (0 sensitive, 1 moderate, 2 tolerant), used only when a soil EC reading is given;
   cost = cash inputs (1 low: saved seed, few inputs … 3 high: hybrid/Bt seed, heavy fertilizer and spraying);
   lab = labour (1 low … 3 high: transplanting, hand-picking); mech = harvest usually needs a thresher/combine or many extra hands. */
const CROPS=[
 {id:"maize",cost:2,lab:2,name:"Maize",fam:"Grass",res:.8,deep:1,val:.7,dur:4,topt:[24,32],tstress:36,water:[450,800],ph:[5.5,7.8]},
 {id:"rice",cost:3,lab:3,mech:1,name:"Rice",fam:"Grass",res:.6,deep:0,val:.75,dur:4,topt:[26,34],tstress:36,water:[900,1500],ph:[5,7.8],wl:1,sandy:.5},
 {id:"wheat",salt:1,cost:2,lab:2,mech:1,name:"Wheat",fam:"Grass",res:.7,deep:1,val:.6,dur:5,topt:[15,25],tstress:30,water:[300,500],ph:[6,8.3],hardy:1},
 {id:"barley",salt:2,cost:1,lab:1,name:"Barley",fam:"Grass",res:.6,deep:0,val:.5,dur:4,topt:[14,24],tstress:30,water:[250,450],ph:[6,8.5],hardy:1},
 {id:"sorghum",salt:1,cost:1,lab:2,name:"Sorghum",fam:"Grass",res:.8,deep:1,val:.5,dur:4,topt:[26,35],tstress:39,water:[350,600],ph:[5.5,8.5]},
 {id:"millet",salt:1,cost:1,lab:1,name:"Pearl millet",fam:"Grass",res:.6,deep:1,val:.45,dur:3,topt:[28,36],tstress:41,water:[250,450],ph:[5,8.3],sandy:1.05},
 {id:"soybean",salt:1,cost:2,lab:2,mech:1,name:"Soybean",fam:"Legume",nfix:1,res:.4,deep:0,val:.65,dur:4,topt:[24,32],tstress:35,water:[450,700],ph:[5.8,7.5]},
 {id:"chickpea",cost:1,lab:1,name:"Chickpea",fam:"Legume",nfix:1,res:.3,deep:1,val:.6,dur:4,topt:[18,28],tstress:33,water:[200,400],ph:[6,8.5]},
 {id:"lentil",cost:1,lab:1,name:"Lentil",fam:"Legume",nfix:1,res:.3,deep:0,val:.55,dur:4,topt:[15,26],tstress:31,water:[200,350],ph:[6,8.2]},
 {id:"groundnut",cost:2,lab:2,name:"Groundnut",fam:"Legume",nfix:1,res:.3,deep:0,val:.65,dur:4,topt:[26,33],tstress:37,water:[400,650],ph:[5.5,7.2],sandy:1.05},
 {id:"cowpea",cost:1,lab:1,name:"Cowpea",fam:"Legume",nfix:1,res:.4,deep:1,val:.45,dur:3,topt:[26,35],tstress:39,water:[250,450],ph:[5.5,7.5],sandy:1.05},
 {id:"pigeonpea",cost:1,lab:1,name:"Pigeon pea",fam:"Legume",nfix:1,res:.6,deep:1,val:.55,dur:5,topt:[27,35],tstress:38,water:[400,650],ph:[5,8.3]},
 {id:"cotton",salt:2,cost:3,lab:3,name:"Cotton",fam:"Mallow",res:.5,deep:1,val:.8,dur:5,topt:[28,36],tstress:40,water:[550,900],ph:[5.8,8.3]},
 {id:"mustard",salt:1,cost:1,lab:1,name:"Mustard / canola",fam:"Brassica",res:.5,deep:1,val:.55,dur:4,topt:[16,26],tstress:30,water:[250,400],ph:[5.5,8.3],hardy:1},
 {id:"potato",cost:3,lab:3,name:"Potato",fam:"Nightshade",res:.2,deep:0,val:.85,dur:4,topt:[16,25],tstress:29,water:[400,600],ph:[5,6.8]},
 {id:"rye_cc",salt:2,cost:1,lab:1,name:"Cereal rye (cover)",fam:"Grass",cover:1,res:.9,deep:1,val:0,dur:4,topt:[8,22],tstress:30,water:[150,300],ph:[5,8],hardy:1},
 {id:"vetch_cc",cost:1,lab:1,name:"Vetch / clover (cover)",fam:"Legume",nfix:1,cover:1,res:.6,deep:0,val:0,dur:4,topt:[10,24],tstress:30,water:[200,350],ph:[5.5,8],hardy:1},
 {id:"sunn_cc",cost:1,lab:1,name:"Sunn hemp (cover)",fam:"Legume",nfix:1,cover:1,res:.8,deep:1,val:0,dur:3,topt:[26,36],tstress:40,water:[250,450],ph:[5,8]},
];
const FALLOW={id:"fallow",name:"Bare fallow",fam:"—",fallow:1,val:0,res:0,cost:0,lab:0};
const BYID=Object.fromEntries([...CROPS,FALLOW].map(c=>[c.id,c]));

function erf(x){const s=Math.sign(x);x=Math.abs(x);const t=1/(1+0.3275911*x);
  return s*(1-(((((1.061405429*t-1.453152027)*t)+1.421413741)*t-0.284496736)*t+0.254829592)*t*Math.exp(-x*x));}
const pAbove=(mean,thr)=>0.5*(1-erf((thr-mean)/(SD*Math.SQRT2)));
const heatDays=(tmax,months,thr)=>months.reduce((s,m)=>s+DIM[m-1]*pAbove(tmax[m-1],thr),0);
const mlist=(start,n)=>Array.from({length:n},(_,i)=>((start-1+i)%12)+1);
const mlabel=ms=>`${MON[ms[0]-1]}–${MON[ms[ms.length-1]-1]}`;

/* Two growing windows: the main one is the 5-month span with the most usable rain while warm enough (Tmax ≥ 12 °C);
   the second follows straight after. Works for monsoon, temperate, bimodal and Mediterranean climates. */
function seasons(clim){
  let best=1,bs=-1e9;
  for(let s=1;s<=12;s++){const v=mlist(s,5).reduce((a,m)=>a+(clim.tmax[m-1]<12?-200:Math.min(clim.rain[m-1],150)),0);if(v>bs){bs=v;best=s;}}
  const w1=mlist(best,5),w2=mlist(((best+4)%12)+1,7); // second season = rest of the year; crops pick their best start
  return [{key:"main",label:"Main season",months:w1},{key:"second",label:"Second season",months:w2}];
}

function suit(c,win,clim,soil,irr){
  let best=null;
  for(let off=0;off<=win.months.length-c.dur;off++){
    const r=suitAt(c,win,win.months.slice(off,off+c.dur),clim,soil,irr);
    if(!best||r.score>best.score) best=r;
  }
  return best;
}
function suitAt(c,win,ms,clim,soil,irr){
  let active=0,fit=0,frost=false;
  ms.forEach(m=>{const t=clim.tmax[m-1];
    if(c.hardy&&t<8) return;                       // dormant under snow/cold: not penalised
    active++;
    if(!c.hardy&&t<10){frost=true;return;}         // frost risk kills non-hardy crops
    const d=t<c.topt[0]?c.topt[0]-t:t>c.topt[1]?t-c.topt[1]:0; fit+=Math.max(0,1-d/8);});
  if(active<2||frost) return {score:0,hd:0,irrigation:0,deficitShare:1,rain:0,sow:ms[0]};
  fit/=active;
  const hd=heatDays(clim.tmax,ms,c.tstress);
  const temp=Math.max(0,fit-Math.min(.5,hd/80));
  const rain=ms.reduce((s,m)=>s+clim.rain[m-1],0);
  const supply=rain*.8+(win.key==="second"?80:0);  // effective rain + stored soil moisture after main season
  const deficit=Math.max(0,c.water[0]-supply);
  const cover={rainfed:0,limited:.5,full:1}[irr];
  let water=Math.min(1,(supply+cover*deficit)/c.water[0]);
  if(supply>c.water[1]*1.8&&!c.wl) water-=.1;
  let soilF=1;
  if(soil.ph<c.ph[0]||soil.ph>c.ph[1]) soilF*=.7;
  if(soil.texture==="sandy") soilF*=(c.sandy||.95);
  if(soil.texture==="clay"&&c.sandy>1) soilF*=.85;   // pod/root crops struggle in heavy clay
  if(soil.drainage==="poor"&&!c.wl) soilF*=.85;
  if(soil.ec>0){const k=c.salt||0,lim=[2,4,8][k];if(soil.ec>lim) soilF*=Math.max(.35,1-(soil.ec-lim)*[.12,.1,.08][k]);} // salinity (EC, dS/m)
  const score=Math.round(100*Math.pow(temp,.6)*Math.pow(Math.max(0,water),.4)*Math.min(1,soilF));
  return {score,hd,irrigation:cover*deficit,deficitShare:deficit/c.water[0],rain,sow:ms[0]};
}

function cropTable(clim,soil,irr,winOverride){
  const win=winOverride||seasons(clim.recent); // plan on the recent climate's growing windows
  const T={};
  CROPS.forEach(c=>{T[c.id]=win.map(w=>({base:suit(c,w,clim.base,soil,irr),recent:suit(c,w,clim.recent,soil,irr)}));});
  return {T,win};
}

/* Stress scenarios: is the plan still sound if the recent trend continues? (sensitivity test) */
const STRESS=[
  {id:"hot",label:"Hotter (+1.5°C)",dT:1.5,rain:1},
  {id:"dry",label:"Drier (−20% rain)",dT:0,rain:.8},
  {id:"hotdry",label:"Hotter and drier",dT:1.5,rain:.8},
  {id:"wet",label:"Wetter (+20% rain)",dT:0,rain:1.2},
];
const stressClimate=(clim,sc)=>({base:clim.recent,recent:{tmax:clim.recent.tmax.map(t=>t+sc.dT),rain:clim.recent.rain.map(r=>r*sc.rain),label:sc.label}});

/* Farmer's local knowledge: "poor" = grew badly for me, "good" = grew well for me, "none" = can't get seed / can't sell,
   "market" = sells well here. Ground truth from the farmer overrides the satellite-based estimate. */
function applyLocal(T,local){
  Object.entries(local||{}).forEach(([id,v])=>{ if(!T[id]) return;
    const adj=v==="poor"?-20:v==="good"?10:0; if(!adj) return;
    T[id].forEach(x=>["base","recent"].forEach(k=>{x[k]={...x[k],score:Math.max(0,Math.min(100,x[k].score+adj))};}));});
  return T;
}

/* Everything the rotation search needs, for the recent climate plus each stress scenario. */
function buildContext(clim,soil,irr,opts){
  const {T,win}=cropTable(clim,soil,irr);
  applyLocal(T,opts.local);
  const Ts=STRESS.map(sc=>applyLocal(cropTable(stressClimate(clim,sc),soil,irr,win).T,opts.local));
  return {T,Ts,win,soil,weights:opts.weights,current:opts.current,local:opts.local||{},family:!!opts.family,budget:opts.budget||"mid",labor:opts.labor||"hire"};
}

function stressReport(seq,ctx){
  return STRESS.map((sc,k)=>{const r=scoreRotation(seq,{...ctx,T:ctx.Ts[k]},true);return {label:sc.label,overall:r.overall,unsuit:r.unsuit,irrYr:r.irrYr};});
}

/* Score a rotation (array of crop ids, alternating main/second season). */
function scoreRotation(seq,ctx,final){
  const {T,soil,weights}=ctx;const known=new Set(ctx.current||[]);let fam=0;
  let prof=0,irr=0,defShare=0,nCrop=0,resil=0,unsuit=0,legumes=0,covers=0,fallows=0,res=0,deep=0,sameFam=0,cost=0,lab=0,pricey=0,mech=0;
  const fams=new Set();
  seq.forEach((id,i)=>{const c=BYID[id],w=i%2;
    if(known.has(id)) fam++;
    if(c.fallow){fallows++;return;}
    const s=T[id][w];nCrop++;
    const val=c.val*((ctx.local||{})[id]==="market"?1.3:1);
    prof+=val*s.recent.score/100; irr+=s.recent.irrigation; defShare+=Math.min(1,s.recent.deficitShare);
    const worst=ctx.Ts?Math.min(...ctx.Ts.map(t=>t[id][w].recent.score)):s.recent.score;
    resil+=.5*(s.recent.score-1.5*Math.max(0,s.base.score-s.recent.score))+.5*worst;
    if(s.recent.score<(c.cover?30:40)) unsuit++;
    cost+=c.cost; lab+=c.lab; if(c.cost>=3) pricey++; if(c.mech) mech++;
    if(c.nfix) legumes++; if(c.cover) covers++; res+=c.res; if(c.deep) deep=1; fams.add(c.fam);
  });
  const L=final?seq.length:seq.length-1;
  for(let i=0;i<L;i++){const a=BYID[seq[i]],b=BYID[seq[(i+1)%seq.length]];if(!a.fallow&&!b.fallow&&a.fam===b.fam) sameFam++;}
  const years=seq.length/2;
  let noFood=0;
  if(ctx.family) for(let y=0;y<Math.floor(seq.length/2);y++){
    const yr=[seq[2*y],seq[2*y+1]].filter(Boolean).map(id=>BYID[id]);
    if(yr.length===2&&!yr.some(c=>!c.cover&&!c.fallow&&(c.fam==="Grass"||c.fam==="Legume"))) noFood++;}
  const omBoost=soil.om==="low"?1.3:soil.om==="high"?.8:1, sandBoost=soil.texture==="sandy"?1.3:1;
  const soilS=Math.max(0,Math.min(100, 30+Math.min(2,legumes)*12*(1+.0)+Math.min(30,fams.size*7)
    +(nCrop?res/nCrop:0)*20*omBoost+deep*8+Math.min(2,covers)*6*sandBoost*omBoost-sameFam*7-fallows*5*sandBoost));
  const profitS=Math.min(100,100*(prof/seq.length)/.6);
  const irrYr=irr/years;
  const waterS=Math.max(0,100*Math.exp(-irrYr/700)*(1-.6*(nCrop?defShare/nCrop:0)));
  const resilS=Math.max(0,Math.min(100,(nCrop?resil/nCrop:0)+Math.min(16,fams.size*4)));
  const avgCost=nCrop?cost/nCrop:0, avgLab=nCrop?lab/nCrop:0;
  // Affordability: cheap inputs, and (if only family labour) light work. Irrigation also costs money.
  const lowcostS=Math.max(0,Math.min(100,100-(Math.max(0,avgCost-1)/2)*70-(ctx.labor==="family"?(Math.max(0,avgLab-1)/2)*30:0)-Math.min(20,irrYr/30)));
  const S={profit:profitS,water:waterS,soil:soilS,resilience:resilS,familiar:100*fam/seq.length,lowcost:lowcostS};
  const wsum=Object.keys(S).map(k=>weights[k]||0).reduce((a,b)=>a+b,0)||1;
  let overall=Object.keys(S).reduce((a,k)=>a+(weights[k]||0)*S[k],0)/wsum-unsuit*10-noFood*12-(ctx.budget==="low"?pricey*8:0)-(ctx.labor==="family"?mech*4:0);
  return {seq,overall:Math.max(0,overall),...S,irrYr,legumes,covers,fallows,sameFam,families:fams.size,unsuit,noFood,avgCost,avgLab,pricey,mech};
}

function recommend(ctx,slots=6,beam=250){
  const L=ctx.local||{};
  const cands=[0,1].map(w=>CROPS.filter(c=>L[c.id]!=="none"&&ctx.T[c.id][w].recent.score>=(c.cover?30:40)).map(c=>c.id).concat("fallow"));
  let B=[[]];
  for(let i=0;i<slots;i++){
    const next=[];B.forEach(s=>cands[i%2].forEach(id=>next.push([...s,id])));
    B=next.map(s=>({s,v:scoreRotation(s,ctx,false).overall})).sort((a,b)=>b.v-a.v).slice(0,beam).map(x=>x.s);
  }
  const scored=B.map(s=>scoreRotation(s,ctx,true)).sort((a,b)=>b.overall-a.overall);
  const out=[];
  const sig=r=>[...new Set(r.seq)].sort().join(",");
  for(const r of scored){ if(out.every(o=>sig(o)!==sig(r))) out.push(r); if(out.length===3) break; }
  return out;
}

function explain(r,ctx){
  const why=[];const names=[...new Set(r.seq)].filter(id=>id!=="fallow").map(id=>BYID[id]);
  if(r.legumes) why.push(`${r.legumes} legume crop${r.legumes>1?"s":""} fix nitrogen, which cuts fertilizer for the next cereal.`);
  if(r.covers) why.push(`Cover crops keep roots in the soil between cash crops, which protects against erosion and feeds soil carbon.`);
  if(r.families>=3) why.push(`${r.families} plant families break pest and disease cycles.`);
  if(r.sameFam===0) why.push("No back-to-back crops from the same family.");
  if(r.fallows) why.push(`${r.fallows} bare-fallow slot${r.fallows>1?"s":""} save water but leave soil exposed. Use mulch or residue cover.`);
  const holding=names.filter(c=>!c.cover).filter(c=>{const s=ctx.T[c.id];return s.some(x=>x.recent.score>0&&x.recent.score>=x.base.score-3);});
  if(holding.length) why.push(`Climate check: ${holding.map(c=>c.name).join(", ")} ${holding.length>1?"have":"has"} held suitability as this location warmed.`);
  why.push(r.irrYr>5?`Needs about ${Math.round(r.irrYr)} mm of irrigation per year.`:"Runs on rainfall alone in a typical recent year.");
  return why;
}

/* Field readings (sensor, test kit, rain gauge) take priority over satellite and map estimates.
   sens = {moist: soil moisture %, ph, ec: dS/m, rain: last main-season total in mm}. All optional. */
function applySensors(clim,soil,sens){
  const s=sens||{},out={clim,soil:{...soil},used:[],rainPct:null,moist:null,salty:false};
  if(s.ph>=3.5&&s.ph<=10){out.soil.ph=+s.ph;out.used.push("ph");}
  if(s.ec>0){out.soil.ec=+s.ec;out.salty=s.ec>4;out.used.push("ec");}
  if(s.rain>0){const win=seasons(clim.recent)[0].months,sat=win.reduce((a,m)=>a+clim.recent.rain[m-1],0);
    if(sat>0){const f=Math.max(.6,Math.min(1.6,s.rain/sat));out.rainPct=Math.round(100*s.rain/sat);
      const sc=p=>({...p,rain:p.rain.map(r=>Math.round(r*f))});out.clim={...clim,base:sc(clim.base),recent:sc(clim.recent)};out.used.push("rain");}}
  if(s.moist>0){const [wp,fc]={sandy:[5,12],loam:[12,27],clay:[22,38]}[soil.texture]||[12,27],a=(s.moist-wp)/(fc-wp);
    out.moist=a<.4?"dry":a>1.05?"wet":"good";out.used.push("moist");}
  return out;
}
/* Logger export: CSV with a header row. Columns are matched by name; values are averaged (rain is summed). */
function parseSensorCsv(text){
  const rows=String(text).trim().split(/\r?\n/).map(r=>r.split(/[,;\t]/).map(x=>x.trim()));
  if(rows.length<2) throw new Error("need a header row and at least one row of readings");
  const find=re=>rows[0].findIndex(h=>re.test(h.toLowerCase()));
  const cols={moist:find(/moist|vwc|humid/),ph:find(/^ph|\bph\b/),ec:find(/\bec\b|salin|conduct/),rain:find(/rain|precip/)};
  const out={};
  Object.entries(cols).forEach(([k,i])=>{if(i<0)return;const v=rows.slice(1).map(r=>parseFloat(r[i])).filter(Number.isFinite);
    if(v.length) out[k]=+(k==="rain"?v.reduce((a,b)=>a+b,0):v.reduce((a,b)=>a+b,0)/v.length).toFixed(k==="rain"?0:1);});
  if(!Object.keys(out).length) throw new Error("no moisture, pH, EC or rain column found");
  return out;
}

/* No-machinery, low-cash advice for a plan: returns tip keys (translated by the UI) plus crops that need extra harvest help. */
function lowCostTips(r){
  const ids=[...new Set(r.seq)].filter(id=>id!=="fallow"),cs=ids.map(id=>BYID[id]);
  const tips=["tipHand"];
  if(cs.some(c=>c.nfix&&!c.cover)) tips.push("tipLegume");
  if(cs.some(c=>c.cover)) tips.push("tipCover");
  tips.push("tipResidue");
  if(cs.some(c=>["millet","sorghum","chickpea","lentil","cowpea","pigeonpea","mustard","barley"].includes(c.id))) tips.push("tipSeed");
  tips.push("tipRent","tipShare");
  return {tips,machineCrops:cs.filter(c=>c.mech||c.lab>=3).map(c=>c.id)};
}

const api={DIM,MON,CROPS,FALLOW,BYID,STRESS,heatDays,seasons,suit,cropTable,buildContext,stressReport,scoreRotation,recommend,explain,mlabel,lowCostTips,applySensors,parseSensorCsv};
if(typeof module!=="undefined") module.exports=api; else root.FS=api;
})(this);
