/* FieldShift farmer mode: language-first, picture-based, voice-enabled, with login.
   Two storage modes:
   - server: the self-hosted Flask app (phone + hashed PIN accounts, lockout, data on your server)
   - device: the static page (data saved only in this browser; clearly labelled, not a security boundary) */
(function(){
const $=id=>document.getElementById(id);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
/* Language: a manual choice always wins. Otherwise: phone language, then the region the phone is in
   (time zone, locale country), then the farm's own region or GPS position. */
const COUNTRY_LANG={IN:"hi",KE:"sw",TZ:"sw",UG:"sw",BR:"pt",PT:"pt",MZ:"pt",AO:"pt",ES:"es",MX:"es",AR:"es",CO:"es",PE:"es",CL:"es",EC:"es",
  GT:"es",BO:"es",PY:"es",UY:"es",VE:"es",HN:"es",NI:"es",CR:"es",PA:"es",DO:"es",SV:"es",CU:"es"};
const TZ_LANG=[[/^Asia\/(Kolkata|Calcutta)$/,"hi"],[/^Africa\/(Nairobi|Dar_es_Salaam|Kampala)$/,"sw"],
  [/^America\/(Sao_Paulo|Manaus|Cuiaba|Campo_Grande|Belem|Fortaleza|Recife|Bahia|Araguaina|Maceio|Porto_Velho|Boa_Vista|Rio_Branco|Santarem|Noronha)$|^Europe\/Lisbon$|^Africa\/(Maputo|Luanda)$/,"pt"],
  [/^America\/(Mexico_City|Monterrey|Tijuana|Cancun|Merida|Chihuahua|Hermosillo|Mazatlan|Bogota|Lima|Santiago|Guayaquil|Guatemala|La_Paz|Asuncion|Montevideo|Caracas|Tegucigalpa|Managua|Costa_Rica|Panama|Santo_Domingo|El_Salvador|Havana)$|^America\/Argentina\/|^Europe\/Madrid$/,"es"]];
function detectLang(){
  const have=Object.keys(I18N), locs=(navigator.languages&&navigator.languages.length?navigator.languages:[navigator.language||"en"]);
  for(const l of locs){const b=String(l).toLowerCase().split("-")[0];if(b!=="en"&&have.includes(b)) return b;}
  try{const tz=Intl.DateTimeFormat().resolvedOptions().timeZone||"";for(const [re,l] of TZ_LANG) if(re.test(tz)) return l;}catch(e){}
  for(const l of locs){const c=(String(l).split("-")[1]||"").toUpperCase();if(COUNTRY_LANG[c]) return COUNTRY_LANG[c];}
  return "en";
}
function langFromLatLon(lat,lon){
  if(lat>=6&&lat<=36&&lon>=68&&lon<=98) return "hi";
  if(lat>=-12&&lat<=5&&lon>=29&&lon<=42) return "sw";
  if(lat>=36.9&&lat<=42.2&&lon>=-9.6&&lon<=-6.2) return "pt";
  if(lat>=36&&lat<=44&&lon>=-9.6&&lon<=3.4) return "es";
  if(lat>=-34&&lat<=5&&lon>=-58&&lon<=-34) return "pt";
  if(lat>=-56&&lat<=33&&lon>=-118&&lon<=-34) return "es";
  return "en";
}
const REGION_LANG={nagpur:"hi",ludhiana:"hi",anantapur:"hi",iowa:"en",nakuru:"sw",mato:"pt"};
const deviceLang=detectLang();
let manual=(()=>{try{return localStorage.getItem("fs_lang")||"";}catch(e){return "";}})();
let lang=manual||deviceLang;
const t=(k,v)=>fill(((FT[lang]||FT.en)[k]??FT.en[k]??k),v||{});
const L=()=>I18N[lang]||I18N.en;
const cropName=id=>L().crops[id]||FS.BYID[id].name;
const mon=m=>L().months[m-1];

/* ---------------- storage ---------------- */
async function call(url,body,method){
  const r=await fetch(url,{method:method||(body?"POST":"GET"),headers:{"Content-Type":"application/json"},body:body?JSON.stringify(body):undefined,credentials:"same-origin"});
  const j=await r.json().catch(()=>({}));
  if(!r.ok) throw (j.code||"error");
  return j;
}
const Store={server:false,mem:{},
  async detect(){try{const r=await fetch("api/health");if(r.ok){const h=await r.json();this.server=!!(h&&h.auth);}}catch(e){}},
  users(){try{return JSON.parse(localStorage.getItem("fs_users")||"{}");}catch(e){return this.mem;}},
  put(u){try{localStorage.setItem("fs_users",JSON.stringify(u));}catch(e){this.mem=u;}},
  async hash(phone,pin){try{const h=await crypto.subtle.digest("SHA-256",new TextEncoder().encode("fieldshift|"+phone+"|"+pin));
    return [...new Uint8Array(h)].map(b=>b.toString(16).padStart(2,"0")).join("");}catch(e){return "p"+phone+pin;}},
  async register(phone,pin,name,role){
    if(this.server) return call("api/register",{phone,pin,name,role});
    const U=this.users(); if(U[phone]) throw "exists";
    U[phone]={name,role,pin:await this.hash(phone,pin),fails:0,until:0,state:null}; this.put(U);
    return {user:{phone,name,role},state:null};},
  async login(phone,pin){
    if(this.server) return call("api/login",{phone,pin});
    const U=this.users(),u=U[phone]; if(!u) throw "wrongPin";
    if(u.until>Date.now()) throw "locked";
    if(u.pin!==await this.hash(phone,pin)){u.fails=(u.fails||0)+1;if(u.fails>=5){u.until=Date.now()+15*60e3;u.fails=0;}this.put(U);throw "wrongPin";}
    u.fails=0;this.put(U);return {user:{phone,name:u.name,role:u.role},state:u.state};},
  async me(){if(!this.server) return null;try{return await call("api/me");}catch(e){return null;}},
  async save(user,state){
    if(!user||user.demo) return;
    if(this.server){try{await call("api/state",{state},"PUT");}catch(e){} return;}
    const U=this.users(); if(U[user.phone]){U[user.phone].state=state;this.put(U);}},
  async logout(){if(this.server){try{await call("api/logout",{});}catch(e){}}},
};

/* ---------------- app state ---------------- */
const A={screen:"home",user:null,state:{farms:[],active:null},err:"",mode:"login",role:"farmer"};
const farm=()=>A.state.farms.find(f=>f.id===A.state.active);
const uid=()=>Math.random().toString(36).slice(2,9);
function newFarm(name,village,region){
  const R=REGIONS[region]||REGIONS.nagpur;
  return {id:uid(),name,village:village||"",region:REGIONS[region]?region:"nagpur",acres:2,irr:region==="ludhiana"?"full":"rainfed",
    budget:"low",labor:"family",current:R.current,family:true,soil:{...R.soil},local:{},climate:null,sensors:{}};
}
function demoState(){
  const mk=(n,v,r,o)=>Object.assign(newFarm(n,v,r),o||{});
  const farms=[mk("Ramesh","Wardha","nagpur",{acres:3}),mk("Gurpreet","Khanna","ludhiana",{acres:5,budget:"mid",labor:"hire"}),
    mk("Lakshmi","Kalyandurg","anantapur",{acres:2}),mk("Wanjiru","Njoro","nakuru",{acres:1.5}),mk("João","Sorriso","mato",{acres:8,budget:"mid"})];
  return {farms,active:farms[0].id};
}
const persist=()=>Store.save(A.user,{...A.state,lang});
function setLang(l){lang=manual=l;try{localStorage.setItem("fs_lang",l);}catch(e){} if(window.syncLang) window.syncLang(l); draw();}
function autoLang(){
  if(manual) return;
  const f=(A.screen==="plan"||A.screen==="setup")?farm():null;
  lang=f?(f.geoLang||(A.user&&A.user.role==="helper"?REGION_LANG[f.region]:"")||deviceLang):deviceLang;
  if(window.syncLang) window.syncLang(lang);
}
function go(screen){if(screen==="setup"&&A.screen!=="setup")A.step=0;A.screen=screen;A.err="";A.anim=true;A.wzAnim=true;stopVoice();closeSheet();autoLang();draw();window.scrollTo(0,0);}

/* ---------------- screens ---------------- */
function topbar(){
  const opts=Object.entries(I18N).map(([k,v])=>`<option value="${k}" ${k===lang?"selected":""}>${v.label}</option>`).join("");
  return `<div class="fx-top"><div class="fx-topin"><div class="fx-brand" id="fxHome" role="link" tabindex="0">${LOGO.replace('width="32" height="32"','width="30" height="30"')}FieldShift</div>
    <div class="fx-topr"><label class="fx-langpick">${ic("globe")}<select id="fxLang" aria-label="Language">${opts}</select></label>
    ${A.user?`<span class="fx-who">${esc(A.user.name)}</span><button class="fx-out" id="fxOut">${t("logout")}</button>`:""}</div></div></div>`;
}
function scrLogin(){
  const reg=A.mode==="register";
  return `<div class="fx-hero"><div class="f3 k-mini"></div><p class="fx-herotag">${t("appTag")}</p></div>
  <h2 class="fx-h">${t("whoAreYou")}</h2>
  <div class="fx-grid2">
    <button class="fx-big ${A.role==="farmer"?"on":""}" data-role="farmer">${ic("farmer","xl")}${t("farmer")}</button>
    <button class="fx-big ${A.role==="helper"?"on":""}" data-role="helper">${ic("helper","xl")}${t("helper")}</button></div>
  <form id="fxForm" class="fx-card" autocomplete="on">
    ${reg?`<label>${ic("user")} ${t("name")}<input id="fxName" maxlength="60" autocomplete="name"></label>`:""}
    <label>${ic("phone")} ${t("phone")}<input id="fxPhone" type="tel" inputmode="numeric" maxlength="15" autocomplete="tel"></label>
    <label>${ic("lock")} ${t("pin")}<input id="fxPin" type="password" inputmode="numeric" maxlength="4" autocomplete="${reg?"new-password":"current-password"}"></label>
    ${A.err?`<p class="fx-err">${ic("warn")} ${t(A.err)}</p>`:""}
    <button class="fx-go" type="submit">${reg?t("create"):t("login")}</button>
    <button class="fx-link" type="button" id="fxSwap">${reg?t("haveAcc"):t("register")}</button>
    <p class="fx-note">${Store.server?t("savedServer"):t("savedDevice")}</p>
  </form>
  <button class="fx-demo" id="fxDemo">${ic("play","f")} ${t("demo")}</button>`;
}
function scrHelper(){
  const regs=Object.entries(REGIONS).map(([k,r])=>`<option value="${k}">${esc(r.name)}</option>`).join("");
  return `<h2 class="fx-h">${t("myFarmers")}</h2>
  <div class="fx-list">${A.state.farms.map(f=>`<button class="fx-row" data-open="${f.id}">${ic("farmer","lg")}
    <span><b>${esc(f.name)}</b><small>${esc([f.village,(REGIONS[f.region]||{name:""}).name].filter(Boolean).join(", "))}</small><small>${f.acres} ${t("acres")}</small></span><span class="fx-arrow">›</span></button>`).join("")}</div>
  <form id="fxAdd" class="fx-card"><h3>${t("addFarmer")}</h3>
    <label>${ic("user")} ${t("farmerName")}<input id="fxFN" maxlength="60" required></label>
    <label>${ic("home")} ${t("village")}<input id="fxFV" maxlength="60"></label>
    <label>${ic("pin")} ${t("where")}<select id="fxFR">${regs}</select></label>
    <button class="fx-go" type="submit">${t("addFarmer")}</button></form>`;
}
function choice(name,val,opts){
  return `<div class="fx-choices">${opts.map(([v,icn,label])=>`<button type="button" class="fx-ch ${v===val?"on":""}" data-set="${name}" data-val="${v}">${ic(icn,"lg")}${label}</button>`).join("")}</div>`;
}
function practiceLabel(k){const seq=PRACTICES[k].seq;const u=[...new Set(seq)];return u.map(id=>cropIc(id)+" "+esc(cropName(id))).join(`<span class="fx-sep">${ic("arrow")}</span>`);}
const cropIc=(id,cls)=>ic(CROP_SVG[id]||"leaf",cls);
const WZ=["where","size","water","money","labor","now","sens"];
function scrSetup(){
  const f=farm(); A.step=Math.max(0,Math.min(WZ.length-1,A.step||0)); const k=WZ[A.step], last=A.step===WZ.length-1;
  const regs=Object.entries(REGIONS).map(([r,v])=>`<option value="${r}" ${f.region===r?"selected":""}>${esc(v.name)}</option>`).join("")+
    (f.climate?`<option value="custom" ${f.region==="custom"?"selected":""}>${t("realData")}</option>`:"");
  const body={
    where:()=>`<button class="fx-go loc-btn" id="fxGeo" type="button">${ic("pin")} ${t("locBtn")}</button>
      <p class="fx-note loc-msg" id="fxGeoMsg" role="status" aria-live="polite">${f.locMsg&&f.locMsg.k?esc(t(f.locMsg.k,f.locMsg.v)):""}</p>
      <select id="fxRegion" class="wz-select" aria-label="${t("where")}">${regs}</select>
      <details class="loc-manual" ${f.lat!=null?"open":""}><summary>${t("orType")}</summary>
        <div class="fx-sens"><label>${t("latLbl")}<input id="fxLat" type="number" inputmode="decimal" step="0.0001" min="-90" max="90" value="${f.lat??""}" placeholder="21.15"></label>
        <label>${t("lonLbl")}<input id="fxLon" type="number" inputmode="decimal" step="0.0001" min="-180" max="180" value="${f.lon??""}" placeholder="79.09"></label></div>
        <button class="fx-ghost" id="fxUseCoords" type="button">${t("useCoords")}</button></details>`,
    size:()=>`<div class="fx-step"><button type="button" data-step="-0.5" aria-label="−">−</button><b>${f.acres}</b><button type="button" data-step="0.5" aria-label="+">+</button></div>
      <div class="wz-plots" aria-hidden="true">${`<i></i>`.repeat(Math.min(24,Math.ceil(f.acres*2)))}</div>`,
    water:()=>choice("irr",f.irr,[["rainfed","rain",t("w_rainfed")],["limited","bucket",t("w_limited")],["full","tap",t("w_full")]]),
    money:()=>`<div class="fx-choices">${[["low",1,t("m_low")],["mid",2,t("m_mid")],["high",3,t("m_high")]].map(([v,n,l])=>`<button type="button" class="fx-ch ${f.budget===v?"on":""}" data-set="budget" data-val="${v}"><span class="fx-coins">${ic("coin","f c-gold").repeat(n)}</span>${l}</button>`).join("")}</div>`,
    labor:()=>choice("labor",f.labor,[["family","family",t("l_family")],["hire","worker",t("l_hire")]]),
    now:()=>`<div class="fx-list wz-list">${Object.keys(PRACTICES).map(p=>`<button type="button" class="fx-ch wide ${f.current===p?"on":""}" data-set="current" data-val="${p}">${practiceLabel(p)}</button>`).join("")}</div>
      <label class="fx-check"><input type="checkbox" id="fxFamily" ${f.family?"checked":""}> ${ic("food")} ${t("family")}</label>`,
    sens:()=>`<p class="fx-note" style="margin:-4px 0 14px">${t("sensNote")}</p>
      <div class="fx-sens">${[["moist","drop","sMoist","0.1"],["ph","flask","sPh","0.1"],["ec","jar","sEc","0.1"],["rain","rain","sRain","1"]].map(([n,icn,lab,st])=>
        `<label>${ic(icn)} ${t(lab)}<input type="number" inputmode="decimal" step="${st}" min="0" data-sens="${n}" value="${(f.sensors||{})[n]??""}"></label>`).join("")}</div>
      ${Store.server&&A.user&&!A.user.demo?`<button class="fx-ghost" id="fxSensLoad" type="button">${ic("sat")} ${t("sLoad")}</button><p class="fx-note" id="fxSensMsg"></p>`:""}`,
  }[k]();
  const title={where:"where",size:"size",water:"water",money:"money",labor:"labor",now:"now",sens:"sensTitle"}[k];
  const from=((A.wzPrev??A.step)+1)/WZ.length*100, to=(A.step+1)/WZ.length*100; A.wzPrev=A.step;
  const anim=A.wzAnim?(A.wzDir<0?"in rev":"in"):""; A.wzAnim=false;
  return `<div class="wz"><div class="wz-top"><button class="fx-link" id="wzBack">‹ ${t("back")}</button><span class="wz-count">${esc(f.name)}, ${A.step+1} / ${WZ.length}</span></div>
    <div class="wz-bar"><i style="--from:${from}%;--to:${to}%"></i></div>
    <div class="wz-step ${anim}"><h2 class="fx-h">${t(title)}</h2>${body}</div>
    <button class="fx-go" id="wzNext">${last?t("showPlan"):t("next")}</button></div>`;
}

/* ---------------- living field: the plan played month by month ---------------- */
const lerp=(a,b,k)=>a+(b-a)*k, clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const hex=c=>[1,3,5].map(i=>parseInt(c.slice(i,i+2),16));
const mix=(c1,c2,k)=>{const a=hex(c1),b=hex(c2);return "#"+a.map((v,i)=>Math.round(lerp(v,b[i],clamp(k,0,1))).toString(16).padStart(2,"0")).join("");};
const FAMCOL={Grass:"#c9930a",Legume:"#2f7d32",Brassica:"#c4551a",Mallow:"#9c3f78",Nightshade:"#6a4fa3"};
const ROWS=[[140,.95,7],[163,1.3,6],[192,1.75,5]];
function sceneSVG(par){
  const plants=ROWS.map(([y,sc,n],r)=>{const k=(y-122)/88,xl=60-k*70+14*sc,xr=300+k*70-14*sc;
    return Array.from({length:n},(_,i)=>`<g class="pl" data-x="${(xl+(xr-xl)*i/(n-1)).toFixed(1)}" data-y="${y}" data-s="${sc}" data-p="${r*7+i}"></g>`).join("");}).join("");
  const furrows=Array.from({length:9},(_,i)=>`<path d="M${60+i*30} 122L${-10+i*47.5} 212"/>`).join("");
  const rain=Array.from({length:22},(_,i)=>`<path d="M${8+i*16.5} ${-10-(i*37)%60}l-5 16" style="animation-delay:${-(i*0.137%0.7).toFixed(2)}s"/>`).join("");
  return `<svg class="sc" viewBox="0 0 360 212" ${par?`preserveAspectRatio="${par}"`:""} role="img" aria-label="${esc(t("appTag"))}">
    <rect class="sc-sky" width="360" height="130" fill="#bfe0f2"/>
    <circle class="sc-sun" cx="298" cy="40" r="16" fill="#f6c544"/>
    <g class="sc-cloud" fill="#fff"><path d="M40 52a12 12 0 0 1 4-23 16 16 0 0 1 30-3 12 12 0 0 1 8 26z"/><path d="M190 40a10 10 0 0 1 3-19 14 14 0 0 1 26-2 10 10 0 0 1 6 21z"/><path d="M262 70a9 9 0 0 1 3-17 12 12 0 0 1 22-2 9 9 0 0 1 5 19z"/></g>
    <path class="sc-hill" d="M0 118C60 96 110 110 170 100S290 92 360 108V135H0z" fill="#9db67f"/>
    <rect class="sc-ground" y="126" width="360" height="86" fill="#8fa672"/>
    <path class="sc-soil" d="M-10 212L60 122H300L370 212z" fill="#a9825a"/>
    <g class="sc-furrow" stroke="#2a211c" stroke-opacity=".22" stroke-width="1.2" fill="none">${furrows}</g>
    <g class="sc-plants" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${plants}</g>
    <g class="sc-rain" stroke="#2c7da0" stroke-width="1.6" stroke-linecap="round" opacity="0">${rain}</g>
  </svg>`;
}
function spansFor(P,seq){const start=P.ctx.win[0].months[0];
  return seq.map((id,i)=>{const w=i%2,y=Math.floor(i/2),c=FS.BYID[id];
    if(c.fallow) return {i,id,c,fallow:true,off:w?5:0,len:w?7:5,s:y*12+(w?5:0),irr:0};
    const r=P.ctx.T[id][w].recent,off=((r.sow-start)+12)%12; return {i,id,c,off,len:Math.min(c.dur,12-off),s:y*12+off,irr:r.irrigation||0};});}
function sceneSpans(P){return spansFor(P,P.best.seq);}
const HL={today:"Grown today",plan:"FieldShift plan",soil:"Soil health",moist:"Soil moisture"};
const SC={t:0,playing:false,raf:0,P:null,spans:[],cur:null,loop:false,els:null,last:0,f3:null,o:{}};
/* what the 3D field needs: the climate, and the two rotations (today, and the plan) as month spans */
function data3d(P,o){
  const C=P.clim.recent,names={},en=!!o.en,lb=o.labels||{};
  FS.CROPS.forEach(c=>names[c.id]=en?c.name.replace(/\s*\(cover\)/,""):cropName(c.id)); names.fallow=en?"Resting":cropName("fallow");
  return {start:P.ctx.win[0].months[0],rain:C.rain,tmax:C.tmax,wet:C.wet||null,names,
    plots:{today:{label:lb.today||t("today"),spans:spansFor(P,P.now.seq),soilFrom:P.now.soil,soilTo:P.now.soil},
           plan:{label:lb.plan||t("newPlan"),spans:sceneSpans(P),soilFrom:P.now.soil,soilTo:P.best.soil}},
    text:{soil:lb.soil||t("rSoil"),moist:lb.moist||t("sMoist").replace(/\s*\(.*\)\s*$/,"")}};
}
function sceneStop(){cancelAnimationFrame(SC.raf);SC.playing=false;if(SC.f3)SC.f3.invalidate();}
function sceneUnmount(){sceneStop();if(SC.f3){try{SC.f3.dispose();}catch(e){}SC.f3=null;}SC.els=null;}
function sceneMount(P,o){
  sceneUnmount(); o=o||{}; const box=$("fx").querySelector(".f3"); if(!box||!P) return;
  SC.P=P; SC.spans=sceneSpans(P); SC.loop=!!o.loop; SC.cur=null; SC.o=o; if(o.t!=null) SC.t=o.t;
  if(window.Farm3D&&Farm3D.supported()){
    try{
      SC.f3=new Farm3D(box,{autoRotate:!!o.autoRotate,satellite:!!o.satellite,onSky:o.onSky,
        onFrame:(dt,now)=>{if(!SC.playing) return false; SC.t+=dt*(SC.loop?1.5:2);
          if(SC.t>=36){if(SC.loop) SC.t=0; else{SC.t=35.99;SC.playing=false;}} sceneDraw(now); return true;},
        onTap:o.en?null:key=>{const list=key==="today"?spansFor(SC.P,SC.P.now.seq):SC.spans,sp=list.filter(x=>SC.t>=x.s&&SC.t<x.s+x.len).pop(); if(sp) openSheet(sp.i,key,false);}});
      SC.f3.setData(data3d(P,o)); SC.f3.setCompare(!!o.compare,false); SC.f3.setView(o.view||"field",false);
    }catch(e){ if(SC.f3){try{SC.f3.dispose();}catch(_){}} SC.f3=null; }
  }
  if(!SC.f3){ /* no WebGL: the flat drawing */
    box.classList.add("f3-flat"); box.innerHTML=sceneSVG(); const svg=box.querySelector(".sc"),q=c=>svg.querySelector(c);
    SC.els={svg,sky:q(".sc-sky"),sun:q(".sc-sun"),cloud:q(".sc-cloud"),hill:q(".sc-hill"),ground:q(".sc-ground"),soil:q(".sc-soil"),rain:q(".sc-rain"),pl:[...svg.querySelectorAll(".pl")]};
    document.querySelectorAll(".f3-only").forEach(el=>el.hidden=true); }
  sceneDraw(0);
  if(o.play) scenePlay(true);
}
function sceneSetPlan(P){SC.P=P;SC.spans=sceneSpans(P);SC.cur=null;if(SC.f3)SC.f3.setData(data3d(P,SC.o));sceneDraw(0);}
function scenePlay(on){
  if(SC.f3){SC.playing=!!on; if(on&&SC.t>=35.9) SC.t=0; SC.f3.invalidate(); sceneDraw(0); return;}
  cancelAnimationFrame(SC.raf); SC.playing=false; if(!on){sceneDraw(0);return;}
  if(SC.t>=35.9) SC.t=0;
  SC.playing=true; SC.last=performance.now();
  const tick=now=>{if(!SC.playing) return; const dt=Math.min(80,now-SC.last); SC.last=now; SC.t+=dt/1000*(SC.loop?1.4:2);
    if(SC.t>=36){if(SC.loop) SC.t=0; else {SC.t=35.99;SC.playing=false;}}
    sceneDraw(now); if(SC.playing) SC.raf=requestAnimationFrame(tick);};
  SC.raf=requestAnimationFrame(tick);
}
function sceneDraw(now){
  const P=SC.P,E=SC.els; if(!P) return; if(!SC.f3&&(!E||!E.svg.isConnected)) return;
  const tm=SC.t,start=P.ctx.win[0].months[0],mi=Math.floor(tm)%12,cm=((start-1+mi)%12)+1,nm=(cm%12)+1,fr=tm-Math.floor(tm),year=Math.min(2,Math.floor(tm/12));
  const C=P.clim.recent,rain=lerp(C.rain[cm-1],C.rain[nm-1],fr),temp=lerp(C.tmax[cm-1],C.tmax[nm-1],fr);
  const soil=lerp(P.now.soil/100,P.best.soil/100,tm/36);
  const sp=SC.spans.filter(x=>tm>=x.s&&tm<x.s+x.len).pop();
  if(SC.f3) SC.f3.setTime(tm);
  else{
    const wet=clamp(rain/170,0,1),hot=clamp((temp-22)/20,0,1);
    E.sky.setAttribute("fill",mix(mix("#bfe0f2","#f4dba6",hot),"#9aaeb9",wet*.75));
    E.sun.setAttribute("r",(13+hot*12).toFixed(1)); E.sun.setAttribute("fill",mix("#f6c544","#e2571b",hot)); E.sun.setAttribute("opacity",(1-wet*.8).toFixed(2));
    E.cloud.setAttribute("opacity",(.15+wet*.85).toFixed(2));
    E.rain.setAttribute("opacity",clamp((rain-45)/110,0,1).toFixed(2));
    E.hill.setAttribute("fill",mix("#c9b98a","#7fa864",wet)); E.ground.setAttribute("fill",mix("#b9a877","#6f9a58",wet));
    E.soil.setAttribute("fill",mix("#b08a62","#4e3320",soil));
    if((sp?sp.i:-1)!==SC.cur){SC.cur=sp?sp.i:-1;
      const inner=sp&&!sp.c.fallow?iconPaths(CROP_SVG[sp.id]||"leaf"):'<path d="M9 22l1-4M12 22v-5M15 22l-1-4" />';
      E.pl.forEach(g=>g.innerHTML=inner);}
    const p=sp?(tm-sp.s)/sp.len:0, grow=!sp||sp.c.fallow?.55:(p<.1?p/.1*.3:.3+.7*(1-Math.pow(1-(p-.1)/.9,2))), fade=sp&&!sp.c.fallow&&p>.94?(1-p)/.06:1;
    const col=!sp||sp.c.fallow?"#8d7a63":mix("#3f8f3a",FAMCOL[sp.c.fam]||"#3f8f3a",clamp((p-.55)/.4,0,1));
    E.pl.forEach((g,i)=>{const x=+g.dataset.x,y=+g.dataset.y,s=+g.dataset.s*grow,rot=SC.playing?Math.sin(now/520+i*1.7)*3:0;
      g.setAttribute("transform",`translate(${x} ${y}) rotate(${rot.toFixed(2)}) scale(${s.toFixed(3)}) translate(-12 -22)`);
      g.setAttribute("stroke",col); g.setAttribute("opacity",fade.toFixed(2));});
  }
  /* readouts beside the field */
  const set=(id,v)=>{const el=$(id);if(el&&el.textContent!==v)el.textContent=v;},en=!!SC.o.en;
  set("scWhen",en?`Year ${year+1}, ${FS.MON[cm-1]}`:`${t("yearN",{y:year+1})}, ${mon(cm)}`);
  set("scCrop",sp?(en?sp.c.name:cropName(sp.id)):(en?"Resting":cropName("fallow")));
  set("scRain",Math.round(rain)+" mm"); set("scTemp",temp.toFixed(0)+"°C");
  const sb=$("scSoil"); if(sb) sb.style.width=(soil*100).toFixed(1)+"%";
  const sl=$("scT"); if(sl&&document.activeElement!==sl) sl.value=tm;
  const pb=$("scPlay"); if(pb&&pb.dataset.on!==String(SC.playing)){pb.dataset.on=String(SC.playing);pb.innerHTML=ic(SC.playing?"pause":"play","f");}
  document.querySelectorAll(".cal-now").forEach((n,y)=>{n.style.display=y===year?"block":"none";if(y===year)n.style.left=((tm-year*12)/12*100).toFixed(2)+"%";});
  document.querySelectorAll(".cal-b").forEach(b=>b.classList.toggle("live",!!sp&&+b.dataset.i===sp.i));
}

/* ---------------- crop detail sheet ---------------- */
function openSheet(i,which,jump){
  const P=SC.P||A.P; if(!P) return; const sp=(which==="today"?spansFor(P,P.now.seq):sceneSpans(P))[i]; if(!sp) return;
  const c=sp.c,id=sp.id,w=i%2,sh=$("fxSheet"); if(!sh) return;
  const sc=c.fallow?null:P.ctx.T[id][w].recent, LL=L();
  const pips=(icn,n,max,cls)=>`<span class="fx-icons">${ic(icn,cls).repeat(n)}<span class="fx-faded">${ic(icn,cls).repeat(max-n)}</span></span>`;
  sh.querySelector(".sheet-in").innerHTML=`<button class="sheet-x" id="fxSheetX" aria-label="${t("close")}">${ic("close")}</button>
    <div class="sheet-head fam-${c.fallow?"Fallow":c.fam}">${cropIc(id,"crop")}<div><h3>${esc(cropName(id))}</h3>${c.fallow?"":`<p>${ic("calendar")} ${t("sow",{m:mon(sc.sow)})}</p>`}</div></div>
    ${c.fallow?"":`<dl class="sheet-rows">
      <div><dt>${t("cFit")}</dt><dd><span class="meter"><i style="width:${sc.score}%"></i></span><b>${sc.score}</b></dd></div>
      <div><dt>${t("cWater")}</dt><dd>${pips("drop",clamp(Math.round(c.water[0]/150),1,6),6,"f c-rain")}<small>${c.water[0]} mm</small></dd></div>
      <div><dt>${t("rCost")}</dt><dd>${pips("cost",c.cost,3,"c-bad")}</dd></div>
      <div><dt>${t("cWork")}</dt><dd>${pips("hand",c.lab,3,"")}</dd></div></dl>
      ${c.nfix?`<p class="sheet-say">${fill(LL.legumes,{list:esc(cropName(id))})}</p>`:""}${c.cover?`<p class="sheet-say">${t("tipCover")}</p>`:""}${c.mech||c.lab>=3?`<p class="sheet-say">${t("tipMachine",{c:esc(cropName(id))})}</p>`:""}`}`;
  sh.hidden=false; requestAnimationFrame(()=>sh.classList.add("open"));
  $("fxSheetX").onclick=closeSheet; $("fxSheetX").focus();
  sceneStop(); if(jump!==false) SC.t=sp.s+sp.len*.7; sceneDraw(0);
}
function closeSheet(){const sh=$("fxSheet"); if(!sh||sh.hidden) return; sh.classList.remove("open"); setTimeout(()=>{sh.hidden=true;},220);}

/* ---------------- landing page ---------------- */
const planCache={};
function planFor(region,irr,budget){const k=[region,irr||"",budget||""].join("|");
  if(!planCache[k]){const f=newFarm("","",region);if(irr)f.irr=irr;f.budget=budget||"low";f.labor=f.budget==="low"?"family":"hire";planCache[k]=computePlan(f);}
  return planCache[k];}
function openDemo(region,opts){
  A.user={name:"Demo",role:"helper",demo:true}; A.state=demoState();
  let f=A.state.farms.find(x=>x.region===region&&!opts);
  if(!f){f=Object.assign(newFarm(REGIONS[region].name.split(",")[0],"",region),opts||{});A.state.farms.unshift(f);}
  A.state.active=f.id; SC.t=0; go("plan");
}
const LOGO=`<svg viewBox="0 0 32 32" width="32" height="32" aria-hidden="true"><rect width="32" height="32" rx="6" fill="#e8a80c"/><path d="M4 24c6-5 18-5 24 0M6 18c5-4 15-4 20 0M9 12c4-3 10-3 14 0" fill="none" stroke="#2a211c" stroke-width="2.4" stroke-linecap="round"/></svg>`;
function spark(P){const b=P.clim.base.tmax,r=P.clim.recent.tmax,lo=Math.min(...b,...r)-1,hi=Math.max(...b,...r)+1;
  const pts=a=>a.map((v,i)=>`${(6+i*228/11).toFixed(1)},${(52-(v-lo)/(hi-lo)*46).toFixed(1)}`).join(" ");
  return `<svg class="lp-spark" viewBox="0 0 240 58" aria-hidden="true"><polyline points="${pts(b)}" fill="none" stroke="#8d8072" stroke-width="1.6" stroke-dasharray="4 4"/><polyline points="${pts(r)}" fill="none" stroke="#e8a80c" stroke-width="2.4" stroke-linejoin="round"/></svg>`;}
function regionCard(k,n){
  const R=REGIONS[k],P=planFor(k),C=P.clim,W=P.ctx.win[0].months,avg=a=>a.reduce((x,y)=>x+y,0)/a.length,sum=a=>W.reduce((q,m)=>q+a[m-1],0);
  const dT=avg(C.recent.tmax)-avg(C.base.tmax),dR=(sum(C.recent.rain)-sum(C.base.rain))/sum(C.base.rain)*100,saved=Math.round(P.now.irrYr-P.best.irrYr);
  const [place,rest]=R.name.split(/,\s*/);
  return `<article class="lp-card rv" style="--d:${n*70}ms"><div class="lp-cardin"><header><div><h3>${esc(place)}</h3><p>${esc(rest||"")}</p></div><span class="lp-tag">${FS.mlabel(W)}</span></header>
    ${spark(P)}
    <dl><div><dt>Daytime highs</dt><dd class="${dT>0?"hot":""}">${dT>0?"+":""}${dT.toFixed(1)}°C</dd></div><div><dt>Season rain</dt><dd>${dR>0?"+":""}${dR.toFixed(0)}%</dd></div><div><dt>Soil score</dt><dd class="good">${Math.round(P.now.soil)} to ${Math.round(P.best.soil)}</dd></div></dl>
    <div class="lp-seq">${P.best.seq.map(id=>`<span class="fam-${FS.BYID[id].fallow?"Fallow":FS.BYID[id].fam}" title="${esc(FS.BYID[id].name)}">${cropIc(id)}</span>`).join("")}</div>
    <footer><span>${saved>30?`${saved} mm less irrigation a year`:P.best.irrYr<5?"Runs on rain alone":"Similar water use"}</span><button type="button" class="lp-btn sm" data-region="${k}">Open plan</button></footer></div></article>`;
}
function langSlide(code,P){const LL=I18N[code],sp=sceneSpans(P),nm=id=>LL.crops[id]||id;
  const slot=i=>sp[i].c.fallow?nm(sp[i].id):`${nm(sp[i].id)} (${LL.months[P.ctx.T[sp[i].id][i%2].recent.sow-1]})`;
  const saved=Math.round(P.now.irrYr-P.best.irrYr),water=P.best.irrYr<5?LL.waterNone:saved>30?fill(LL.waterLess,{n:saved}):fill(LL.waterNeed,{n:Math.round(P.best.irrYr)});
  return `<div class="lp-slide" lang="${code}"><div><span class="lp-tag">${LL.label}</span><h3>${LL.title}</h3>${[0,1,2].map(y=>`<p class="yr">${fill(LL.year,{y:y+1,a:slot(2*y),b:slot(2*y+1)})}</p>`).join("")}<p>${water}</p><p>${fill(LL.start,{a:1,A:4})}</p></div></div>`;}
function scrHome(){
  A.try=A.try||{region:{sw:"nakuru",pt:"mato"}[deviceLang]||"nagpur",irr:"rainfed",budget:"low",acres:4};
  const regOpts=sel=>Object.entries(REGIONS).map(([k,r])=>`<option value="${k}" ${sel===k?"selected":""}>${esc(r.name)}</option>`).join("");
  const langs=Object.entries(I18N).map(([k,v])=>`<option value="${k}" ${k===lang?"selected":""}>${v.label}</option>`).join("");
  const why=[["sat","Built on NASA climate records","Thirty years of NASA POWER temperature, rainfall and root-zone wetness for any farm on Earth, compared then against now."],
    ["farmer","Made for small farms","Plans start on a quarter of the land, keep food on the family plate and fit the money and labour a farmer really has."],
    ["speaker","Pictures and voice, not jargon","Drops, suns and coins instead of charts. One tap reads the whole plan aloud in the farmer's language."],
    ["hand","No costly machines","Every plan says what can be done by hand or bullock, what to rent for a day and which seed to save."],
    ["flask","Uses field readings","A rain gauge, a pH strip or a soil probe overrides the satellite estimate for that field."],
    ["lock","Farm data stays with the farmer","Plans are worked out on the device. Only a 50 km grid square is ever sent to NASA."]];
  const faq=[["Are the numbers on this page real NASA data?","The six demo farms use illustrative climate values modeled on typical norms, and they are labelled as demo. The detailed view fetches real NASA POWER data for any coordinates."],
    ["How exact is the advice?","It is area-level guidance. One NASA POWER grid square is about 50 km wide, and crop thresholds are general agronomic values. A soil test and the farmer's own experience take priority, and plans should be tried on part of the land first."],
    ["Does a farmer need to read English?","No. The farmer view works in English, Hindi, Spanish, Portuguese and Swahili, uses pictures for every number and can read the plan aloud. The translations are machine-drafted and still need native-speaker review."],
    ["What does it cost?","Nothing. FieldShift is open source and uses free public data from NASA and ISRIC."],
    ["Who built it?","A team at the NASA Space Apps Challenge 2026, for the challenge Field Shift: Adapting Farms with NASA Data."]];
  return `<div class="lp">
  <nav class="lp-nav"><a class="lp-brand" href="#top">${LOGO}<span>FieldShift</span></a>
    <div class="lp-links"><a href="#farms">Demo farms</a><a href="#estimate">Estimate</a><a href="#why">Why it works</a><a href="#voice">Farmer view</a><a href="#faq">Questions</a></div>
    <div class="lp-navr"><label class="lp-lang">${ic("globe")}<select id="fxLang" aria-label="Language">${langs}</select></label><button type="button" class="lp-btn" id="lpOpen">Open the app</button></div></nav>

  <header class="lp-hero" id="top">
    <div class="lp-heroin">
      <div class="lp-copy"><span class="lp-tag">NASA Space Apps Challenge 2026</span>
        <h1>Your climate has moved. <mark>Your crop plan should too.</mark></h1>
        <p>FieldShift turns thirty years of NASA climate data, your soil and your budget into a three-year crop rotation that saves water, rebuilds soil and holds up in a hotter future.</p>
        <div class="lp-cta"><button type="button" class="lp-btn" id="lpDemo">Try the demo village</button><button type="button" class="lp-btn ghost" id="lpLogin">${ic("user")} Log in</button></div>
        <ul class="lp-stats"><li><b data-count="18">18</b><span>crops compared</span></li><li><b data-count="36">36</b><span>months planned</span></li><li><b data-count="5">5</b><span>languages</span></li><li><b data-count="4">4</b><span>future climates tested</span></li></ul>
      </div>
      <div class="lp-stage"><div class="f3"></div>
        <div class="lp-hud tl"><div><b id="scWhen"></b><div id="scCrop" style="color:var(--muted);font-size:14px"></div></div></div>
        <div class="lp-hud tr"><span>${ic("drop","f c-rain")}<b id="scRain"></b></span><span>${ic("thermo","c-sun")}<b id="scTemp"></b></span></div>
        <div class="lp-stagectl f3-only"><div class="seg" role="group"><button type="button" data-view="field" class="on">Field</button><button type="button" data-view="soil">Under the soil</button><button type="button" data-view="top">From above</button></div><span class="lp-drag">Drag to turn</span></div>
      </div>
    </div>
    <form class="lp-try" id="lpTry"><div><h2>${ic("pin")} Plan a field</h2><p>Demo locations use illustrative climate values.</p></div>
      <label>Location<select id="tryRegion">${regOpts(A.try.region)}</select></label>
      <label>Water<select id="tryIrr"><option value="rainfed">Rain only</option><option value="limited">Some irrigation</option><option value="full">Full irrigation</option></select></label>
      <label>Money for seed and inputs<select id="tryBudget"><option value="low">Little</option><option value="mid">Some</option><option value="high">Enough</option></select></label>
      <button class="lp-btn ink" type="submit">Show the plan</button></form>
  </header>

  <section class="lp-sec" id="farms"><div class="lp-in"><div class="lp-head rv"><span class="lp-tag">Demo farms</span><h2>Six farms, six different shifts</h2><p>The dashed line is daytime temperature for 1991 to 2005 and the gold line is the last fifteen years. The row of crops is the suggested three-year rotation.</p></div>
    <div class="lp-grid" id="lpCards">${Object.keys(REGIONS).map(()=>`<div class="lp-card sk"></div>`).join("")}</div></div></section>

  <section class="lp-banner"><div class="lp-in rv"><div><h2>Planning for your own village?</h2><p>Enter coordinates, fetch thirty years of NASA POWER data and run the same analysis on real measurements.</p></div><button type="button" class="lp-btn" id="lpData">Use real NASA data</button></div></section>

  <section class="lp-sec" id="estimate"><div class="lp-in lp-two"><div class="rv"><span class="lp-tag">Quick estimate</span><h2>What a better rotation saves</h2>
      <p>Move the slider to your farm size. The numbers compare what is grown today with FieldShift's first suggestion for that location.</p>
      <ul class="lp-points"><li>${ic("drop")}<div><b>Less pumped water</b><span>Crops matched to the rain that actually falls now.</span></div></li>
        <li>${ic("soil")}<div><b>Healthier soil</b><span>Legumes, cover crops and no back-to-back repeats.</span></div></li>
        <li>${ic("warn")}<div><b>Tested against the future</b><span>Each plan is re-scored for a hotter and a drier climate.</span></div></li></ul></div>
    <div class="lp-est rv"><label>Location<select id="estRegion">${regOpts(A.try.region==="nagpur"?"ludhiana":A.try.region)}</select></label>
      <label>Farm size <b id="estAcresV">4 acres</b><input type="range" id="estAcres" min="0.5" max="20" step="0.5" value="4"></label>
      <div class="lp-est2"><div><span>Pumped today</span><b id="estNow">0</b></div><div><span>With the plan</span><b id="estNew">0</b></div></div>
      <div class="lp-big"><span>Water saved each year</span><b id="estSaved">0</b></div>
      <div class="lp-bars"><div><span>Soil health today</span><i><u id="estSoilA"></u></i></div><div><span>Soil health with the plan</span><i><u id="estSoilB" class="g"></u></i></div></div>
      <p class="lp-fine">From demo climate values. One millimetre of water on one acre is about 4,047 litres.</p></div></div></section>

  <section class="lp-sec alt" id="why"><div class="lp-in"><div class="lp-head center rv"><h2>Why farmers can use it</h2><p>Earlier tools were built for large farms and expert users. FieldShift starts from the smallholder.</p></div>
    <div class="lp-why">${why.map(([i,h,p],n)=>`<article class="rv" style="--d:${n*60}ms">${ic(i,"lg")}<h3>${h}</h3><p>${p}</p></article>`).join("")}</div>
    <div class="lp-src rv"><span>Data from</span><b>NASA POWER</b><b>MERRA-2</b><b>ISRIC SoilGrids</b></div></div></section>

  <section class="lp-sec" id="voice"><div class="lp-in"><div class="lp-head center rv"><h2>The same plan, in the farmer's language</h2><p>This is what the farmer reads or hears. No charts, no scores.</p></div>
    <div class="lp-car rv" id="lpCar"><div class="lp-track" id="lpTrack"></div>
      <div class="lp-carctl"><button type="button" id="lpPrev" aria-label="Previous">‹</button><div class="lp-dots" id="lpDots"></div><button type="button" id="lpNext" aria-label="Next">›</button></div></div></div></section>

  <section class="lp-sec alt" id="faq"><div class="lp-in lp-two"><div class="rv"><h2>Honest answers</h2><p>What FieldShift can and cannot tell a farmer.</p><button type="button" class="lp-btn" id="lpDemo2">Try the demo village</button></div>
    <div class="lp-faq rv">${faq.map(([q,a])=>`<details><summary>${q}</summary><p>${a}</p></details>`).join("")}</div></div></section>

  <footer class="lp-foot"><div class="lp-in"><div><a class="lp-brand" href="#top">${LOGO}<span>FieldShift</span></a><p>A crop-rotation planner for a changing climate.</p></div>
    <div><h4>Explore</h4><a href="#farms">Demo farms</a><a href="#estimate">Estimate</a><a href="#voice">Farmer view</a></div>
    <div><h4>Data</h4><a href="https://power.larc.nasa.gov/" target="_blank" rel="noopener">NASA POWER</a><a href="https://soilgrids.org/" target="_blank" rel="noopener">ISRIC SoilGrids</a></div>
    <div><h4>Project</h4><span>NASA Space Apps Challenge 2026</span><span>Field Shift: Adapting Farms with NASA Data</span></div></div></footer>
  </div>`;
}
function tween(el,to,fmt){if(!el)return;const from=+el.dataset.v||0,t0=performance.now(),calm=window.matchMedia&&matchMedia("(prefers-reduced-motion: reduce)").matches;
  el.dataset.v=to; if(calm){el.textContent=fmt(to);return;}
  const stepFn=now=>{const k=Math.min(1,(now-t0)/450),e=1-Math.pow(1-k,3);el.textContent=fmt(from+(to-from)*e);if(k<1)requestAnimationFrame(stepFn);};requestAnimationFrame(stepFn);}
function bindHome(){
  const calm=window.matchMedia&&matchMedia("(prefers-reduced-motion: reduce)").matches;
  const on=(id,ev,fn)=>{const el=$(id);if(el)el[ev]=fn;};
  on("lpOpen","onclick",()=>go("login")); on("lpLogin","onclick",()=>go("login"));
  const demo=()=>{A.user={name:"Demo",role:"helper",demo:true};A.state=demoState();go("helper");};
  on("lpDemo","onclick",demo); on("lpDemo2","onclick",demo);
  on("lpData","onclick",()=>{window.openExpert&&window.openExpert(newFarm("My farm","",A.try.region),demoClimate(REGIONS[A.try.region]));const b=document.querySelector('nav button[data-tab="data"]');if(b)b.click();});
  $("tryIrr").value=A.try.irr; $("tryBudget").value=A.try.budget;
  on("lpTry","onsubmit",e=>{e.preventDefault();A.try.region=$("tryRegion").value;A.try.irr=$("tryIrr").value;A.try.budget=$("tryBudget").value;
    openDemo(A.try.region,{irr:A.try.irr,budget:A.try.budget,labor:A.try.budget==="low"?"family":"hire",acres:A.try.acres});});
  document.querySelectorAll('.lp a[href^="#"]').forEach(a=>a.onclick=e=>{e.preventDefault();const el=document.getElementById(a.getAttribute("href").slice(1));if(el)el.scrollIntoView({behavior:calm?"auto":"smooth",block:"start"});});
  // reveal on scroll
  const io="IntersectionObserver" in window?new IntersectionObserver(en=>en.forEach(x=>{if(x.isIntersecting){x.target.classList.add("in");io.unobserve(x.target);}}),{threshold:.12}):null;
  const watch=()=>document.querySelectorAll(".lp .rv:not(.in)").forEach(el=>io?io.observe(el):el.classList.add("in"));
  watch();
  // stats count up
  document.querySelectorAll("[data-count]").forEach(b=>{b.dataset.v=0;tween(b,+b.dataset.count,v=>String(Math.round(v)));});
  // region cards (computed after first paint)
  setTimeout(()=>{const box=$("lpCards");if(!box)return;box.innerHTML=Object.keys(REGIONS).map((k,n)=>regionCard(k,n)).join("");
    box.querySelectorAll("[data-region]").forEach(b=>b.onclick=()=>openDemo(b.dataset.region));watch();},60);
  // estimator
  const est=()=>{const r=$("estRegion");if(!r)return;const P=planFor(r.value),ac=+$("estAcres").value,L1=mm=>mm*ac*4047;
    $("estAcresV").textContent=ac+(ac===1?" acre":" acres");
    const fmtL=v=>v>=1e6?(v/1e6).toFixed(1)+" million litres":Math.round(v/1000).toLocaleString()+" thousand litres";
    tween($("estNow"),L1(P.now.irrYr),v=>v<1?"Rain only":fmtL(v)); tween($("estNew"),L1(P.best.irrYr),v=>v<1?"Rain only":fmtL(v));
    tween($("estSaved"),Math.max(0,L1(P.now.irrYr-P.best.irrYr)),v=>v<1?"Already rain-fed":fmtL(v));
    $("estSoilA").style.width=P.now.soil+"%"; $("estSoilB").style.width=P.best.soil+"%";};
  on("estRegion","onchange",est); on("estAcres","oninput",est); setTimeout(est,120);
  // language carousel
  setTimeout(()=>{const tr=$("lpTrack");if(!tr)return;const codes=Object.keys(I18N),P=planFor(A.try.region);
    tr.innerHTML=codes.map(c=>langSlide(c,P)).join(""); $("lpDots").innerHTML=codes.map((c,i)=>`<button type="button" data-dot="${i}" aria-label="${I18N[c].label}"></button>`).join("");
    let idx=Math.max(0,codes.indexOf(lang));
    const show=i=>{idx=(i+codes.length)%codes.length;tr.style.transform=`translateX(${-idx*100}%)`;document.querySelectorAll("[data-dot]").forEach((d,n)=>d.classList.toggle("on",n===idx));};
    show(idx); on("lpPrev","onclick",()=>{show(idx-1);stop();}); on("lpNext","onclick",()=>{show(idx+1);stop();});
    document.querySelectorAll("[data-dot]").forEach(d=>d.onclick=()=>{show(+d.dataset.dot);stop();});
    clearInterval(A.carTimer); const stop=()=>clearInterval(A.carTimer);
    if(!calm) A.carTimer=setInterval(()=>{if(!$("lpTrack"))return stop();show(idx+1);},4500);
    $("lpCar").onmouseenter=stop;},90);
  // nav shadow
  const nav=document.querySelector(".lp-nav"); window.onscroll=()=>{if(nav.isConnected)nav.classList.toggle("stuck",window.scrollY>20);};
}

/* ---------------- plan + pictographs ---------------- */
function climateOf(f){return f.region==="custom"&&f.climate?{name:f.name,source:"power",...f.climate}:demoClimate(REGIONS[f.region]||REGIONS.nagpur);}
function computePlan(f){
  const S=FS.applySensors(climateOf(f),f.soil,f.sensors), clim=S.clim, cur=PRACTICES[f.current]||PRACTICES.cotton_fallow;
  const weights={profit:3,water:f.irr==="rainfed"?2:4,soil:4,resilience:4,familiar:3,lowcost:{low:5,mid:2,high:0}[f.budget]};
  const ctx=FS.buildContext(clim,S.soil,f.irr,{weights,current:cur.seq,local:f.local,family:f.family,budget:f.budget,labor:f.labor});
  const best=FS.recommend(ctx)[0], now=FS.scoreRotation(cur.seq,ctx,true);
  return {clim,ctx,best,now,S};
}
const icons=(name,n,max,cls)=>{n=Math.max(0,Math.min(max,Math.round(n)));return `<span class="fx-icons" role="img" aria-label="${n} / ${max}">${Array.from({length:n},(_,i)=>ic(name,cls).replace('<svg ','<svg style="--n:'+i+'" ')).join("")}<span class="fx-faded">${ic(name,cls).repeat(max-n)}</span></span>`;};
function thermo(temp,label,cls){
  const h=Math.max(6,Math.min(100,(temp-15)/(45-15)*100));
  return `<div class="fx-thermo ${cls}"><svg viewBox="0 0 40 120" width="40" height="120" aria-hidden="true">
    <rect x="14" y="6" width="12" height="92" rx="6" fill="var(--line)"/>
    <rect x="14" y="${98-h*0.92}" width="12" height="${h*0.92}" rx="6" fill="${cls==="now"?"var(--bad)":"var(--sun)"}"/>
    <circle cx="20" cy="104" r="12" fill="${cls==="now"?"var(--bad)":"var(--sun)"}"/></svg>
    <b>${temp.toFixed(1)}°C</b><small>${label}</small></div>`;
}
function risk(r,ctx){
  const st=FS.stressReport(r.seq,ctx),worst=Math.min(...st.map(x=>x.overall)),weak=Math.max(...st.map(x=>x.unsuit));
  return weak>=2||worst<45?["r",t("riskHigh")]:weak===1||worst<65?["y",t("riskMid")]:["g",t("riskLow")];
}
function scrPlan(){
  const f=farm(), P=computePlan(f), {clim,ctx,best,now,S}=P, W=ctx.win[0].months;
  const avg=a=>a.reduce((x,y)=>x+y,0)/a.length, sum=(a,ms)=>ms.reduce((s,m)=>s+a[m-1],0);
  const tb=avg(W.map(m=>clim.base.tmax[m-1])), tr=avg(W.map(m=>clim.recent.tmax[m-1]));
  const rb=sum(clim.base.rain,W), rr=sum(clim.recent.rain,W);
  const hb=FS.heatDays(clim.base.tmax,W,35), hr=FS.heatDays(clim.recent.tmax,W,35);
  const dT=avg(clim.recent.tmax)-avg(clim.base.tmax);
  const pa=Math.max(.25,Math.round(f.acres*.25*4)/4);
  const tile=(i)=>{const id=best.seq[i],w=i%2,c=FS.BYID[id];
    return `<div class="fx-tile fam-${c.fallow?"Fallow":c.fam}"><span class="fx-season">${w?t("secondSeason"):t("mainSeason")}</span>
      ${cropIc(id,"crop")}<b>${esc(cropName(id))}</b>${id==="fallow"?"":`<small>${ic("calendar")} ${t("sow",{m:mon(ctx.T[id][w].recent.sow)})}</small>`}</div>`;};
  const bucket=r=>r.irrYr<5?`<span class="fx-icons">${ic("rain","c-rain")}</span> <small>${t("onlyRain")}</small>`:icons("bucket",r.irrYr/100,8,"f c-rain")+` <small>${Math.round(r.irrYr)} mm</small>`;
  const costN=r=>r.avgCost?1+(r.avgCost-1)*2:0;
  const [rkN,rkNw]=risk(now,ctx),[rkB,rkBw]=risk(best,ctx);
  const tips=FS.lowCostTips(best);
  const tipIcon={tipHand:"hand",tipLegume:"pulse",tipCover:"leaf",tipResidue:"nofire",tipSeed:"jar",tipRent:"wrench",tipShare:"share"};
  const tipsHtml=tips.tips.map(k=>`<li>${ic(tipIcon[k],"lg")}<span>${t(k)}</span></li>`).join("")+
    tips.machineCrops.map(id=>`<li class="warn">${ic("warn","lg")}<span>${t("tipMachine",{c:esc(cropName(id))})}</span></li>`).join("");
  // sentences reused from the expert farmer card
  const LL=L(), legs=[...new Set(best.seq)].filter(id=>FS.BYID[id].nfix).map(cropName);
  const saved=Math.round(now.irrYr-best.irrYr);
  const waterS=best.irrYr<5?LL.waterNone:saved>30?fill(LL.waterLess,{n:saved}):fill(LL.waterNeed,{n:Math.round(best.irrYr)});
  let weak=null;FS.STRESS.forEach((sc,k)=>best.seq.forEach((id,i)=>{if(id==="fallow"||weak)return;const c=FS.BYID[id];if(ctx.Ts[k][id][i%2].recent.score<(c.cover?30:40))weak=id;}));
  const d=(dT>0?"+":"")+dT.toFixed(1), climS=weak?fill(LL.fragile,{d,c:cropName(weak)}):fill(LL.robust,{d});
  const startS=fill(LL.start,{a:pa,A:f.acres});
  A.voice=[LL.title,...[0,1,2].map(y=>`${t("yearN",{y:y+1})}: ${cropName(best.seq[2*y])}, ${best.seq[2*y]==="fallow"?"":t("sow",{m:mon(ctx.T[best.seq[2*y]][0].recent.sow)})}. ${cropName(best.seq[2*y+1])}${best.seq[2*y+1]==="fallow"?"":", "+t("sow",{m:mon(ctx.T[best.seq[2*y+1]][1].recent.sow)})}.`),
    waterS,climS,legs.length?fill(LL.legumes,{list:legs.join(", ")}):"",startS,t("cheapTitle")+". "+t(tips.tips[0])].filter(Boolean);
  const dropKey=t("eachDrop").replace("💧",ic("drop","f c-rain")), sunKey=t("eachSun").replace(/☀️?/,ic("sun","c-sun"));
  const listen=t("listen").replace(/^[^\p{L}]+/u,"");
  /* crop calendar: one 12-month ruler per year, starting at the first month of the rainy season */
  const start=ctx.win[0].months[0];
  const ruler=`<div class="cal-ruler" aria-hidden="true">${Array.from({length:12},(_,i)=>`<span>${mon(((start-1+i)%12)+1)}</span>`).join("")}</div>`;
  const spans=sceneSpans(P), span=i=>spans[i]; A.P=P;
  const lane=i=>{const b=span(i);return `<div class="cal-lane"><button type="button" class="cal-b fam-${b.c.fallow?"Fallow":b.c.fam}" data-i="${i}" style="margin-left:${(b.off/12*100).toFixed(2)}%;width:${(b.len/12*100).toFixed(2)}%">${cropIc(b.id)}<b>${esc(cropName(b.id))}</b></button></div>`;};
  const key=i=>{const b=span(i);return `<li class="fam-${b.c.fallow?"Fallow":b.c.fam}"><button type="button" data-i="${i}">${cropIc(b.id,"lg")}<span><b>${esc(cropName(b.id))}</b>${b.c.fallow?"":`<small>${t("sow",{m:mon(ctx.T[b.id][i%2].recent.sow)})}</small>`}</span></button></li>`;};
  const cal=[0,1,2].map(y=>`<div class="cal-year"><h4>${t("yearN",{y:y+1})}</h4>${ruler}<div class="cal-lanes"><i class="cal-now"></i>${lane(2*y)}${lane(2*y+1)}</div><ul class="cal-key">${key(2*y)}${key(2*y+1)}</ul></div>`).join("");
  /* field readings */
  const fr=[]; const sv=f.sensors||{};
  if(S.moist) fr.push([{dry:"y",good:"g",wet:"y"}[S.moist],t({dry:"moistDry",good:"moistGood",wet:"moistWet"}[S.moist]),sv.moist+"%"]);
  if(S.salty) fr.push(["r",t("saltHigh"),sv.ec+" dS/m"]);
  if(S.rainPct!=null) fr.push(["g",t("rainAdj",{p:S.rainPct}),sv.rain+" mm"]);
  if(S.used.includes("ph")) fr.push(["g",t("phUsed",{v:sv.ph}),""]);
  if(S.moist) A.voice.splice(1,0,fr[0][1]);
  return `<div class="fx-sec fx-headsec">
    <div class="fx-planhead">${A.user&&A.user.role==="helper"?`<button class="fx-link" id="fxBack">‹ ${t("back")}</button>`:"<span></span>"}
      <span class="fx-badge ${clim.source==="demo"?"demo":"real"}">${clim.source==="demo"?t("demoData"):t("realData")}</span></div>
    <h2 class="fx-h">${esc(f.name)}</h2>
    <p class="fx-meta">${esc([f.village,f.acres+" "+t("acres")].filter(Boolean).join(", "))}</p>
    <button class="fx-go" id="fxListen">${ic("speaker")} ${listen}</button>
    <p class="fx-note" id="fxVoiceMsg"></p>
  </div>

  <section class="fx-sec fx-field"><h3>${esc(LL.title)}</h3>
    <div class="sc-wrap"><div class="f3"></div>
      <div class="sc-cap"><div><b id="scWhen"></b><span id="scCrop"></span></div>
        <div class="sc-chips"><span>${ic("drop","f c-rain")}<b id="scRain"></b></span><span>${ic("thermo","c-sun")}<b id="scTemp"></b></span></div></div>
      <div class="sc-soilrow">${ic("soil","c-leaf")}<span>${t("rSoil")}</span><span class="meter"><i id="scSoil"></i></span></div>
      <div class="sc-ctl"><button type="button" id="scPlay" aria-label="play">${ic("play","f")}</button>
        <div class="sc-track"><input type="range" id="scT" min="0" max="35.99" step="0.01" value="0" aria-label="${esc(LL.title)}">
          <div class="sc-years"><span>${t("yearN",{y:1})}</span><span>${t("yearN",{y:2})}</span><span>${t("yearN",{y:3})}</span></div></div></div>
      <div class="sc-views f3-only"><div class="seg" role="group">${[["field","vField"],["soil","vSoil"],["top","vTop"]].map(([v,k])=>`<button type="button" data-view="${v}" class="${(A.view||"field")===v?"on":""}">${t(k)}</button>`).join("")}</div>
        <label class="sc-cmp"><input type="checkbox" id="scCmp" ${A.cmp?"checked":""}> ${t("vCompare")}</label></div>
    </div>
    <p class="fx-note sc-hint">${t("tapCrop")} <span class="f3-only">${t("dragHint")}</span></p>
    <div class="cal">${cal}</div>
    <p class="fx-startline">${ic("check")} ${startS}</p>
  </section>

  ${fr.length?`<section class="fx-sec"><h3>${t("sensTitle")}</h3><ul class="fx-read">${fr.map(([d,txt,v])=>`<li><i class="dot ${d}"></i><span>${txt}</span>${v?`<b>${esc(v)}</b>`:""}</li>`).join("")}</ul></section>`:""}

  <section class="fx-sec"><h3>${t("compareTitle")}</h3>
    <table class="fx-cmp"><tr><th></th><th>${t("today")}</th><th class="new">${t("newPlan")}</th></tr>
      <tr><td>${t("rWater")}</td><td>${bucket(now)}</td><td class="new">${bucket(best)}</td></tr>
      <tr><td>${t("rSoil")}</td><td>${icons("soil",now.soil/20,5,"c-leaf")}</td><td class="new">${icons("soil",best.soil/20,5,"c-leaf")}</td></tr>
      <tr><td>${t("rMoney")}</td><td>${icons("coin",now.profit/20,5,"f c-gold")}</td><td class="new">${icons("coin",best.profit/20,5,"f c-gold")}</td></tr>
      <tr><td>${t("rCost")}</td><td>${icons("cost",costN(now),5,"c-bad")}</td><td class="new">${icons("cost",costN(best),5,"c-bad")}</td></tr>
      <tr><td>${t("rRisk")}</td><td class="fx-risk"><i class="dot ${rkN}"></i>${rkNw}</td><td class="fx-risk new"><i class="dot ${rkB}"></i>${rkBw}</td></tr></table>
    <p class="fx-say">${waterS}</p><p class="fx-say">${climS}</p>${legs.length?`<p class="fx-say">${fill(LL.legumes,{list:legs.join(", ")})}</p>`:""}
  </section>

  <section class="fx-sec"><h3>${t("weatherTitle")}</h3>
    <div class="fx-weather">${thermo(tb,t("before"),"then")}<div class="fx-delta ${dT>0?"hot":""}">${dT>=0?t("hotter",{d:dT.toFixed(1)}):t("cooler",{d:Math.abs(dT).toFixed(1)})}</div>${thermo(tr,t("nowLbl"),"now")}</div>
    <div class="fx-pg"><div class="fx-pgl">${t("rainLbl")} <small>(${dropKey})</small></div>
      <div class="fx-pgr"><span class="fx-pgk">${t("before")}</span>${icons("drop",rb/100,15,"f c-rain")}<small>${Math.round(rb)} mm</small></div>
      <div class="fx-pgr"><span class="fx-pgk">${t("nowLbl")}</span>${icons("drop",rr/100,15,"f c-rain")}<small>${Math.round(rr)} mm</small></div></div>
    <div class="fx-pg"><div class="fx-pgl">${t("hotDays")} <small>(${sunKey})</small></div>
      <div class="fx-pgr"><span class="fx-pgk">${t("before")}</span>${icons("sun",hb/5,20,"c-sun")}<small>${Math.round(hb)}</small></div>
      <div class="fx-pgr"><span class="fx-pgk">${t("nowLbl")}</span>${icons("sun",hr/5,20,"c-sun")}<small>${Math.round(hr)}</small></div></div>
  </section>

  <section class="fx-sec fx-cheap"><h3>${t("cheapTitle")}</h3><ul>${tipsHtml}</ul></section>

  <div class="fx-sec fx-tail"><div class="fx-actions"><button class="fx-ghost" id="fxEdit">${ic("edit")} ${t("edit")}</button><button class="fx-ghost" id="fxExpert">${ic("chart")} ${t("expert")}</button></div>
    <p class="fx-note">${t("profileNote")}</p></div>`;
}

/* ---------------- voice ---------------- */
function stopVoice(){try{speechSynthesis.cancel();}catch(e){}}
function speak(){
  const msg=$("fxVoiceMsg");
  try{
    if(!("speechSynthesis" in window)) throw 0;
    stopVoice();
    const code=(FT[lang]||FT.en).tts, voices=speechSynthesis.getVoices(), v=voices.find(x=>x.lang&&x.lang.toLowerCase().startsWith(code.slice(0,2)));
    if(voices.length&&!v) msg.textContent=t("noVoice");
    (A.voice||[]).forEach(line=>{const u=new SpeechSynthesisUtterance(line);u.lang=code;if(v)u.voice=v;u.rate=.9;speechSynthesis.speak(u);});
  }catch(e){msg.textContent=t("noVoice");}
}

/* ---------------- current location ---------------- */
function openManual(){const d=document.querySelector(".loc-manual");if(d)d.open=true;}
function nearestRegion(la,lo){let best=null;
  for(const [k,r] of Object.entries(REGIONS)){const R=6371,dLa=(r.lat-la)*Math.PI/180,dLo=(r.lon-lo)*Math.PI/180,
    h=Math.sin(dLa/2)**2+Math.cos(la*Math.PI/180)*Math.cos(r.lat*Math.PI/180)*Math.sin(dLo/2)**2,km=2*R*Math.asin(Math.sqrt(h));
    if(!best||km<best.km) best={k,km};}
  return best;}
async function useLocation(la,lo){
  const f=farm(); if(!f) return; const m=$("fxGeoMsg"),btn=$("fxGeo"),say=x=>{if(m)m.textContent=x;};
  f.lat=+la.toFixed(4); f.lon=+lo.toFixed(4); f.geoLang=langFromLatLon(la,lo);
  if(Store.server){
    say(t("locNasa")); if(btn) btn.disabled=true;
    const q=`lat=${la}&lon=${lo}`;
    try{
      const ctl=window.AbortController?new AbortController():null, to=setTimeout(()=>ctl&&ctl.abort(),120000);
      const r=await fetch("api/climate?"+q,{credentials:"same-origin",signal:ctl?ctl.signal:undefined}); clearTimeout(to);
      const c=await r.json().catch(()=>({})); if(!r.ok||!c.base) throw new Error(c.code||"nasaFail");
      f.climate={base:c.base,recent:c.recent}; f.region="custom";
      try{const s2=await call("api/soil?"+q);f.soil={texture:s2.texture,om:s2.om,ph:s2.ph,drainage:f.soil.drainage||"good"};}catch(e){}
      f.locMsg={k:"locDone",v:{lat:f.lat,lon:f.lon}}; persist(); autoLang(); A.wzAnim=false; draw(); return;
    }catch(e){ if(btn) btn.disabled=false; say(t(e&&e.message==="badCoords"?"badCoords":"locFail")); persist(); return; }
  }
  /* this page has no server, so it can't reach NASA: use the nearest demo farm and say so */
  const n=nearestRegion(la,lo); f.region=n.k; f.soil={...REGIONS[n.k].soil}; f.current=REGIONS[n.k].current;
  f.locMsg={k:"locNear",v:{r:REGIONS[n.k].name,k:Math.round(n.km).toLocaleString()}}; persist(); autoLang(); A.wzAnim=false; draw();
}

/* ---------------- draw + events ---------------- */
function draw(){
  const root=$("fx");
  const body={home:scrHome,login:scrLogin,helper:scrHelper,setup:scrSetup,plan:scrPlan}[A.screen]();
  const anim=A.anim; A.anim=false;
  clearInterval(A.carTimer);
  root.innerHTML=(A.screen==="home"?body:topbar()+`<div class="fx-main fx-${A.screen}${anim?" enter":""}">${body}</div>`)+`<div class="sheet" id="fxSheet" hidden><div class="sheet-bg"></div><div class="sheet-in" role="dialog" aria-modal="true"></div></div>${A.screen==="home"?"":`<footer class="fx-foot">FieldShift, built for the NASA Space Apps Challenge 2026. Climate data from NASA POWER. Soil data from ISRIC SoilGrids.</footer>`}`;
  root.setAttribute("lang",lang||"en");
  bind();
  const calm=window.matchMedia&&matchMedia("(prefers-reduced-motion: reduce)").matches;
  const hero=$("fx").querySelector(".lp-hero");
  if(A.screen==="home"){bindHome(); if(!A.heroP) try{A.heroP=planFor(A.try.region);}catch(e){}
    sceneMount(A.heroP,{loop:true,t:anim?2:SC.t,play:!calm,satellite:true,autoRotate:true,en:true,
      labels:{today:"Grown today",plan:"FieldShift plan",soil:"Soil health",moist:"Soil moisture"},
      onSky:(a,b)=>{if(hero){hero.style.setProperty("--sky1",a);hero.style.setProperty("--sky2",b);}}});}
  else if(A.screen==="plan") sceneMount(A.P,{t:anim?0:SC.t,play:anim&&!calm,view:A.view||"field",compare:!!A.cmp});
  else if(A.screen==="login"){ if(!A.heroP) try{A.heroP=computePlan(newFarm("","",{sw:"nakuru",pt:"mato"}[deviceLang]||"nagpur"));}catch(e){}
    sceneMount(A.heroP,{loop:true,t:anim?2:SC.t,play:!calm,autoRotate:true}); }
  else sceneUnmount();
}
function after(res){
  A.mode="login"; A.user=res.user; A.state=res.state&&res.state.farms?res.state:{farms:[],active:null};
  if(A.user.role==="helper") return go("helper");
  SC.t=0;
  if(!A.state.farms.length){const f=newFarm(A.user.name,"",{sw:"nakuru",pt:"mato"}[deviceLang]||"nagpur");A.state.farms=[f];A.state.active=f.id;persist();return go("setup");}
  A.state.active=A.state.farms[0].id; go("plan");
}
function bind(){
  const on=(id,ev,fn)=>{const el=$(id);if(el)el[ev]=fn;};
  on("fxLang","onchange",e=>setLang(e.target.value));
  on("fxHome","onclick",()=>go("home"));
  on("fxOut","onclick",async()=>{stopVoice();await Store.logout();A.user=null;A.state={farms:[],active:null};A.mode="login";go("login");});
  document.querySelectorAll("[data-role]").forEach(b=>b.onclick=()=>{A.role=b.dataset.role;draw();});
  on("fxSwap","onclick",()=>{A.mode=A.mode==="register"?"login":"register";A.err="";draw();});
  on("fxDemo","onclick",()=>{A.user={name:"Demo",role:"helper",demo:true};A.state=demoState();go("helper");});
  on("fxForm","onsubmit",async e=>{e.preventDefault();
    const phone=($("fxPhone").value||"").replace(/\D/g,""),pin=$("fxPin").value||"",name=($("fxName")||{}).value;
    if(phone.length<10||phone.length>15){A.err="badPhone";return draw();}
    if(!/^\d{4}$/.test(pin)){A.err="badPin";return draw();}
    if(A.mode==="register"&&!(name||"").trim()){A.err="badName";return draw();}
    try{after(A.mode==="register"?await Store.register(phone,pin,name.trim(),A.role):await Store.login(phone,pin));}
    catch(code){A.err=["wrongPin","locked","exists","badPhone","badPin","badName"].includes(code)?code:"wrongPin";draw();}});
  document.querySelectorAll("[data-open]").forEach(b=>b.onclick=()=>{A.state.active=b.dataset.open;go("plan");});
  on("fxAdd","onsubmit",e=>{e.preventDefault();const f=newFarm($("fxFN").value.trim(),$("fxFV").value.trim(),$("fxFR").value);
    A.state.farms.push(f);A.state.active=f.id;persist();go("setup");});
  on("fxBack","onclick",()=>go("helper"));
  const step=d=>{A.step+=d;A.wzDir=d;A.wzAnim=true;draw();window.scrollTo(0,0);};
  on("wzBack","onclick",()=>A.step>0?step(-1):go("plan"));
  on("wzNext","onclick",()=>A.step<WZ.length-1?step(1):go("plan"));
  on("scPlay","onclick",()=>scenePlay(!SC.playing));
  document.querySelectorAll("[data-view]").forEach(b=>b.onclick=()=>{A.view=b.dataset.view;document.querySelectorAll("[data-view]").forEach(x=>x.classList.toggle("on",x===b));if(SC.f3)SC.f3.setView(A.view,true);});
  on("scCmp","onchange",e=>{A.cmp=e.target.checked;if(SC.f3)SC.f3.setCompare(A.cmp,true);});
  on("scT","oninput",e=>{sceneStop();SC.t=+e.target.value;sceneDraw(0);});
  document.querySelectorAll(".cal [data-i]").forEach(b=>b.onclick=()=>openSheet(+b.dataset.i));
  const bg=document.querySelector("#fxSheet .sheet-bg"); if(bg) bg.onclick=closeSheet;
  const cmp=document.querySelector(".fx-cmp");
  if(cmp){if("IntersectionObserver" in window){const io=new IntersectionObserver(en=>{if(en.some(x=>x.isIntersecting)){cmp.classList.add("in");io.disconnect();}},{threshold:.35});io.observe(cmp);}else cmp.classList.add("in");}
  on("fxRegion","onchange",e=>{const f=farm(),v=e.target.value;f.region=v;f.locMsg=null;if(REGIONS[v])f.geoLang="";if(REGIONS[v]){f.soil={...REGIONS[v].soil};f.current=REGIONS[v].current;}persist();draw();});
  document.querySelectorAll("[data-step]").forEach(b=>b.onclick=()=>{const f=farm();f.acres=Math.max(.5,Math.min(100,+(f.acres+ +b.dataset.step).toFixed(1)));persist();draw();});
  document.querySelectorAll("[data-set]").forEach(b=>b.onclick=()=>{farm()[b.dataset.set]=b.dataset.val;persist();draw();
    if(["irr","budget","labor"].includes(b.dataset.set)&&A.step<WZ.length-1) setTimeout(()=>{if(A.screen==="setup")step(1);},260);});
  document.querySelectorAll("[data-sens]").forEach(el=>el.onchange=()=>{const f=farm();f.sensors=f.sensors||{};const v=parseFloat(el.value);
    if(Number.isFinite(v)&&v>0) f.sensors[el.dataset.sens]=v; else delete f.sensors[el.dataset.sens]; persist();});
  on("fxSensLoad","onclick",async()=>{const m=$("fxSensMsg");try{const r=await call("api/sensor");
    if(!r.latest){m.textContent=t("sNone")+" POST /api/sensor/"+r.key;return;}
    farm().sensors={...(farm().sensors||{}),...r.latest};persist();draw();}catch(e){m.textContent=t("sNone");}});
  on("fxFamily","onchange",e=>{farm().family=e.target.checked;persist();});
  on("fxEdit","onclick",()=>go("setup"));
  on("fxListen","onclick",speak);
  on("fxExpert","onclick",()=>{stopVoice();window.openExpert&&window.openExpert(farm(),climateOf(farm()));});
  on("fxGeo","onclick",()=>{
    const m=$("fxGeoMsg"),say=x=>{if(m)m.textContent=x;};
    if(!window.isSecureContext&&!/^(localhost|127\.0\.0\.1)$/.test(location.hostname)){say(t("locNone"));openManual();return;}
    if(!navigator.geolocation){say(t("locNone"));openManual();return;}
    say(t("locWait")); const btn=$("fxGeo"); if(btn) btn.disabled=true;
    let done=false; const guard=setTimeout(()=>{if(!done){done=true;if(btn)btn.disabled=false;say(t("locTimeout"));openManual();}},20000);
    try{
      navigator.geolocation.getCurrentPosition(p=>{if(done)return;done=true;clearTimeout(guard);useLocation(p.coords.latitude,p.coords.longitude);},
        err=>{if(done)return;done=true;clearTimeout(guard);if(btn)btn.disabled=false;
          say(t(err&&err.code===1?"locDenied":err&&err.code===3?"locTimeout":"locNone"));openManual();},
        {enableHighAccuracy:false,timeout:15000,maximumAge:600000});
    }catch(e){done=true;clearTimeout(guard);if(btn)btn.disabled=false;say(t("locNone"));openManual();}
  });
  on("fxUseCoords","onclick",()=>{const la=parseFloat($("fxLat").value),lo=parseFloat($("fxLon").value),m=$("fxGeoMsg");
    if(!Number.isFinite(la)||!Number.isFinite(lo)||Math.abs(la)>90||Math.abs(lo)>180){if(m)m.textContent=t("badCoords");return;}
    useLocation(la,lo);});
}

window.FS_lang={detectLang,langFromLatLon,deviceLang};
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeSheet();});
window.showFarmer=()=>{$("expert").classList.add("hide");$("fx").classList.remove("hide");draw();};
(async function start(){
  await Store.detect();
  const me=await Store.me();
  if(me&&me.user){after(me);return;}
  A.screen="home"; A.anim=true; draw();
})();
})();
