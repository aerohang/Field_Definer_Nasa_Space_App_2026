/* Demo regions: ILLUSTRATIVE values modeled on typical climate normals, not NASA measurements.
   dT = warming added per month for the "recent" period; dR = rainfall multiplier per month.
   Soil = typical soil for the area (a farmer would enter their soil test / Soil Health Card instead). */
(function(root){
const REGIONS={
 nagpur:{name:"Nagpur, India (black cotton soil)",lat:21.15,lon:79.09,
  tmax:[29,32,36,40,43,38,31,30,32,32,30,28],rain:[12,10,15,10,15,170,320,280,180,60,15,8],
  dT:[.6,.7,.8,.9,.9,1.1,.6,.5,.6,.7,.6,.6],dR:[1,1,1.1,1,1,.72,.92,1.05,1.2,1.15,1,1],
  soil:{texture:"clay",om:"medium",ph:7.8,drainage:"poor"},current:"cotton_fallow"},
 ludhiana:{name:"Ludhiana, India (Punjab)",lat:30.90,lon:75.85,
  tmax:[19,22,27,34,39,38,34,33,33,31,26,21],rain:[25,30,25,12,18,70,210,190,110,15,5,12],
  dT:[.4,1.1,1.3,.8,.6,.5,.4,.4,.5,.6,.7,.5],dR:[1,.9,.85,1,1.1,.9,.92,1.05,1.18,1.2,1,.9],
  soil:{texture:"loam",om:"low",ph:8.0,drainage:"good"},current:"rice_wheat"},
 anantapur:{name:"Anantapur, India (drylands)",lat:14.68,lon:77.60,
  tmax:[30,33,36,38,38,34,32,32,32,31,29,28],rain:[3,3,5,15,45,55,65,85,130,110,35,8],
  dT:[.6,.7,.8,.8,.8,.8,.7,.6,.6,.6,.6,.6],dR:[1,1,1,1,1.05,.8,.85,.95,1.15,1.15,1,1],
  soil:{texture:"sandy",om:"low",ph:6.8,drainage:"good"},current:"groundnut_fallow"},
 iowa:{name:"Central Iowa, USA",lat:41.6,lon:-93.6,
  tmax:[-1,2,9,17,23,28,30,29,25,18,9,1],rain:[25,28,55,90,120,125,105,105,80,65,50,35],
  dT:[.8,.7,.6,.4,.3,.4,.3,.3,.5,.5,.6,.8],dR:[1.05,1.05,1.1,1.1,1.15,1.1,.9,.9,1,1.05,1.05,1.05],
  soil:{texture:"loam",om:"high",ph:6.3,drainage:"good"},current:"maize_soy"},
 nakuru:{name:"Nakuru, Kenya (two rainy seasons)",lat:-0.3,lon:36.07,
  tmax:[27,28,28,26,25,24,23,23,25,26,25,26],rain:[30,40,70,130,110,70,90,100,70,50,60,40],
  dT:[.5,.5,.6,.6,.5,.5,.4,.4,.5,.5,.5,.5],dR:[1.1,1,.95,.85,.9,1,1,1,1.05,1.2,1.25,1.1],
  soil:{texture:"loam",om:"medium",ph:6.0,drainage:"good"},current:"maize_maize"},
 mato:{name:"Mato Grosso, Brazil (soy belt)",lat:-12.5,lon:-55.7,
  tmax:[31,31,31,32,32,32,33,34,34,33,32,31],rain:[290,260,230,120,50,10,5,15,60,150,220,270],
  dT:[.6,.6,.6,.7,.8,.8,.9,1,1.1,.9,.7,.6],dR:[1,1,.95,.85,.8,1,1,1,.85,.8,.95,1],
  soil:{texture:"clay",om:"medium",ph:5.2,drainage:"good"},current:"soy_maize"},
};
const PRACTICES={
 rice_wheat:{name:"Rice → Wheat, every year",seq:["rice","wheat","rice","wheat","rice","wheat"]},
 cotton_fallow:{name:"Cotton, then fallow, every year",seq:["cotton","fallow","cotton","fallow","cotton","fallow"]},
 groundnut_fallow:{name:"Groundnut, then fallow, every year",seq:["groundnut","fallow","groundnut","fallow","groundnut","fallow"]},
 maize_soy:{name:"Maize / soybean, winters bare",seq:["maize","fallow","soybean","fallow","maize","fallow"]},
 maize_maize:{name:"Maize in both seasons",seq:["maize","maize","maize","maize","maize","maize"]},
 soy_maize:{name:"Soybean → second-crop maize",seq:["soybean","maize","soybean","maize","soybean","maize"]},
 millet_mustard:{name:"Pearl millet → Mustard",seq:["millet","mustard","millet","mustard","millet","mustard"]},
};
function demoClimate(r){
  return {name:r.name,source:"demo",
    base:{tmax:r.tmax.slice(),rain:r.rain.slice(),label:"1991–2005"},
    recent:{tmax:r.tmax.map((t,i)=>+(t+r.dT[i]).toFixed(1)),rain:r.rain.map((p,i)=>Math.round(p*r.dR[i])),label:"2010–2024"}};
}
const api={REGIONS,PRACTICES,demoClimate};
if(typeof module!=="undefined") module.exports=api; else Object.assign(root,api);
})(this);
