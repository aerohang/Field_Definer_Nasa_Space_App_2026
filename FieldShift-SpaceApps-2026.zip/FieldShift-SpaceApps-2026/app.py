"""FieldShift backend: NASA POWER climate (baseline vs recent) and SoilGrids soil for any location.

Run:  pip install -r requirements.txt && python app.py   ->  http://localhost:5000
"""
from __future__ import annotations

import calendar
import functools
import json
import os
import re
import secrets
import sqlite3
import time
from collections import defaultdict

import requests
from flask import Flask, g, jsonify, request, send_from_directory, session
from werkzeug.security import check_password_hash, generate_password_hash

POWER_DAILY = "https://power.larc.nasa.gov/api/temporal/daily/point"
import datetime as _dt

_LAST = _dt.date.today().year - 1           # latest complete year: the plan updates itself every year
BASELINE = (1991, 2005)
RECENT = (_LAST - 14, _LAST)
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

app = Flask(__name__, static_folder="static", static_url_path="")

# ---------------- accounts (phone + 4-digit PIN) ----------------
DATA_DIR = os.environ.get("FIELDSHIFT_DATA", os.path.join(os.path.dirname(os.path.abspath(__file__)), "data"))
os.makedirs(DATA_DIR, exist_ok=True)
DB_PATH = os.path.join(DATA_DIR, "fieldshift.db")
MAX_FAILS, LOCK_SECONDS, MAX_STATE_BYTES = 5, 15 * 60, 256_000


def _secret_key() -> bytes:
    """Random per-install key kept in data/ (never in the code), so session cookies can't be forged."""
    path = os.path.join(DATA_DIR, "secret.key")
    if not os.path.exists(path):
        with open(path, "wb") as f:
            f.write(secrets.token_bytes(32))
    with open(path, "rb") as f:
        return f.read()


app.config.update(SECRET_KEY=_secret_key(), SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                  PERMANENT_SESSION_LIFETIME=30 * 24 * 3600)


def db() -> sqlite3.Connection:
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.executescript("""
          CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, phone TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('farmer','helper')), pin_hash TEXT NOT NULL,
            fails INTEGER NOT NULL DEFAULT 0, locked_until REAL NOT NULL DEFAULT 0, created REAL NOT NULL);
          CREATE TABLE IF NOT EXISTS sensors(user_id INTEGER PRIMARY KEY REFERENCES users(id), key TEXT UNIQUE NOT NULL,
            json TEXT, updated REAL);
          CREATE TABLE IF NOT EXISTS states(user_id INTEGER PRIMARY KEY REFERENCES users(id), json TEXT NOT NULL, updated REAL NOT NULL);""")
    return g.db


@app.teardown_appcontext
def _close_db(_exc):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def _err(code: str, status: int = 400):
    return jsonify(code=code), status


def _user_json(row) -> dict:
    return {"phone": row["phone"], "name": row["name"], "role": row["role"]}


def _state_for(user_id: int):
    row = db().execute("SELECT json FROM states WHERE user_id=?", (user_id,)).fetchone()
    return json.loads(row["json"]) if row else None


def _current_user():
    uid = session.get("uid")
    return db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone() if uid else None


@app.post("/api/register")
def register():
    b = request.get_json(silent=True) or {}
    phone = re.sub(r"\D", "", str(b.get("phone", "")))
    pin, name, role = str(b.get("pin", "")), str(b.get("name", "")).strip()[:60], b.get("role")
    if not 10 <= len(phone) <= 15:
        return _err("badPhone")
    if not re.fullmatch(r"\d{4}", pin):
        return _err("badPin")
    if not name:
        return _err("badName")
    if role not in ("farmer", "helper"):
        return _err("badRole")
    try:
        cur = db().execute("INSERT INTO users(phone,name,role,pin_hash,created) VALUES(?,?,?,?,?)",
                           (phone, name, role, generate_password_hash(pin), time.time()))
        db().commit()
    except sqlite3.IntegrityError:
        return _err("exists", 409)
    session.clear()
    session["uid"], session.permanent = cur.lastrowid, True
    return jsonify(user={"phone": phone, "name": name, "role": role}, state=None)


@app.post("/api/login")
def login():
    b = request.get_json(silent=True) or {}
    phone, pin = re.sub(r"\D", "", str(b.get("phone", ""))), str(b.get("pin", ""))
    row = db().execute("SELECT * FROM users WHERE phone=?", (phone,)).fetchone()
    if row is None:
        generate_password_hash(pin)  # same work either way, so timing doesn't reveal which numbers have accounts
        return _err("wrongPin", 401)
    if row["locked_until"] > time.time():
        return _err("locked", 429)
    if not check_password_hash(row["pin_hash"], pin):
        fails = row["fails"] + 1
        locked = time.time() + LOCK_SECONDS if fails >= MAX_FAILS else 0
        db().execute("UPDATE users SET fails=?, locked_until=? WHERE id=?", (0 if locked else fails, locked, row["id"]))
        db().commit()
        return _err("locked" if locked else "wrongPin", 429 if locked else 401)
    db().execute("UPDATE users SET fails=0, locked_until=0 WHERE id=?", (row["id"],))
    db().commit()
    session.clear()
    session["uid"], session.permanent = row["id"], True
    return jsonify(user=_user_json(row), state=_state_for(row["id"]))


@app.post("/api/logout")
def logout():
    session.clear()
    return jsonify(ok=True)


@app.get("/api/me")
def me():
    row = _current_user()
    if row is None:
        return _err("notLoggedIn", 401)
    return jsonify(user=_user_json(row), state=_state_for(row["id"]))


@app.put("/api/state")
def put_state():
    row = _current_user()
    if row is None:
        return _err("notLoggedIn", 401)
    raw = request.get_data(cache=False, as_text=True)
    if len(raw.encode()) > MAX_STATE_BYTES:
        return _err("tooLarge", 413)
    try:
        state = json.loads(raw)["state"]
        assert isinstance(state, dict)
    except (ValueError, KeyError, AssertionError):
        return _err("badState")
    db().execute("INSERT INTO states(user_id,json,updated) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET json=excluded.json, updated=excluded.updated",
                 (row["id"], json.dumps(state), time.time()))
    db().commit()
    return jsonify(ok=True)


@functools.lru_cache(maxsize=256)
def fetch_power_daily(lat: float, lon: float, start: int, end: int) -> dict:
    """Daily Tmax (°C), corrected precipitation (mm/day) and root-zone soil wetness (0-1) from NASA POWER (community=AG)."""
    params = {
        "parameters": "T2M_MAX,PRECTOTCORR,GWETROOT",
        "community": "AG",
        "latitude": lat,
        "longitude": lon,
        "start": f"{start}0101",
        "end": f"{end}1231",
        "format": "JSON",
    }
    r = requests.get(POWER_DAILY, params=params, timeout=90)
    r.raise_for_status()
    return r.json()["properties"]["parameter"]


POWER_MONTHLY = "https://power.larc.nasa.gov/api/temporal/monthly/point"


@functools.lru_cache(maxsize=256)
def fetch_power_monthly(lat: float, lon: float, start: int, end: int) -> dict:
    """Smaller, faster request used when the daily one fails or times out."""
    params = {"parameters": "T2M_MAX,PRECTOTCORR,GWETROOT", "community": "AG", "latitude": lat, "longitude": lon,
              "start": start, "end": end, "format": "JSON"}
    r = requests.get(POWER_MONTHLY, params=params, timeout=60)
    r.raise_for_status()
    return r.json()["properties"]["parameter"]


def monthly_from_monthly(param: dict, years: tuple[int, int]) -> dict:
    """Climatology from NASA POWER monthly values (keys YYYYMM; month 13 is the annual value and is skipped).
    PRECTOTCORR is mm/day, so it is multiplied by the days in the month."""
    acc = {k: defaultdict(list) for k in ("T2M_MAX", "PRECTOTCORR", "GWETROOT")}
    for name, series in param.items():
        if name not in acc:
            continue
        for key, v in series.items():
            if len(key) != 6 or not key.isdigit():
                continue
            y, m = int(key[:4]), int(key[4:])
            if years[0] <= y <= years[1] and 1 <= m <= 12 and v is not None and v > -900:
                acc[name][m].append(v * calendar.monthrange(y, m)[1] if name == "PRECTOTCORR" else v)
    avg = lambda name, m, nd: round(sum(acc[name][m]) / len(acc[name][m]), nd) if acc[name][m] else None
    out = {"tmax": [avg("T2M_MAX", m, 1) for m in range(1, 13)],
           "rain": [None if avg("PRECTOTCORR", m, 0) is None else int(avg("PRECTOTCORR", m, 0)) for m in range(1, 13)],
           "label": f"{years[0]}–{years[1]}"}
    if any(acc["GWETROOT"].values()):
        out["wet"] = [avg("GWETROOT", m, 3) for m in range(1, 13)]
    return out


def monthly_climatology(param: dict, years: tuple[int, int]) -> dict:
    """Average monthly Tmax and average monthly rain total over a span of years. Skips -999 fill values."""
    tsum, tn = defaultdict(float), defaultdict(int)
    rain_by_year_month = defaultdict(float)
    rain_days = defaultdict(int)
    for day, t in param["T2M_MAX"].items():
        y, m = int(day[:4]), int(day[4:6])
        if not (years[0] <= y <= years[1]):
            continue
        p = param["PRECTOTCORR"].get(day, -999)
        if t > -900:
            tsum[m] += t
            tn[m] += 1
        if p > -900:
            rain_by_year_month[(y, m)] += p
            rain_days[(y, m)] += 1
    wsum, wn = defaultdict(float), defaultdict(int)
    for day, g in param.get("GWETROOT", {}).items():
        y, m = int(day[:4]), int(day[4:6])
        if years[0] <= y <= years[1] and g > -900:
            wsum[m] += g
            wn[m] += 1
    tmax, rain = [], []
    for m in range(1, 13):
        tmax.append(round(tsum[m] / tn[m], 1) if tn[m] else None)
        totals = []
        for y in range(years[0], years[1] + 1):
            n = rain_days.get((y, m), 0)
            full = calendar.monthrange(y, m)[1]
            if n >= full * 0.9:  # only use months with near-complete records
                totals.append(rain_by_year_month[(y, m)] * full / n)
        rain.append(round(sum(totals) / len(totals)) if totals else None)
    out = {"tmax": tmax, "rain": rain, "label": f"{years[0]}–{years[1]}"}
    if wn:
        out["wet"] = [round(wsum[m] / wn[m], 3) if wn[m] else None for m in range(1, 13)]
    return out


def heat_days(param: dict, years: tuple[int, int], months: list[int], threshold: float) -> float:
    """Exact average count per year of days above a threshold (daily data, no approximation)."""
    count = 0
    for day, t in param["T2M_MAX"].items():
        y, m = int(day[:4]), int(day[4:6])
        if years[0] <= y <= years[1] and m in months and t > threshold:
            count += 1
    return round(count / (years[1] - years[0] + 1), 1)


# ---------------- field sensors ----------------
# A device (for example an ESP32 with a soil probe) sends readings with:  POST /api/sensor/<device key>
#   {"moist": 23.5, "ph": 7.1, "ec": 0.8, "rain": 12}      (any subset; rain = mm since the last message)
SENSOR_RANGES = {"moist": (0, 100), "ph": (3, 10.5), "ec": (0, 50), "rain": (0, 5000)}


def _sensor_row(user_id: int):
    row = db().execute("SELECT * FROM sensors WHERE user_id=?", (user_id,)).fetchone()
    if row is None:
        db().execute("INSERT INTO sensors(user_id,key) VALUES(?,?)", (user_id, secrets.token_urlsafe(12)))
        db().commit()
        row = db().execute("SELECT * FROM sensors WHERE user_id=?", (user_id,)).fetchone()
    return row


@app.get("/api/sensor")
def sensor_latest():
    user = _current_user()
    if user is None:
        return _err("notLoggedIn", 401)
    row = _sensor_row(user["id"])
    return jsonify(key=row["key"], latest=json.loads(row["json"]) if row["json"] else None, updated=row["updated"])


@app.post("/api/sensor/<key>")
def sensor_push(key: str):
    row = db().execute("SELECT * FROM sensors WHERE key=?", (key,)).fetchone()
    if row is None:
        return _err("unknownDevice", 404)
    body = request.get_json(silent=True) or {}
    latest = json.loads(row["json"]) if row["json"] else {}
    accepted = {}
    for name, (lo, hi) in SENSOR_RANGES.items():
        v = body.get(name)
        if isinstance(v, (int, float)) and not isinstance(v, bool) and lo <= v <= hi:
            accepted[name] = round(float(v), 2)
    if not accepted:
        return _err("noValidReading")
    if "rain" in accepted:  # rain accumulates across messages; the others are the latest value
        accepted["rain"] = round(latest.get("rain", 0) + accepted["rain"], 1)
    latest.update(accepted)
    db().execute("UPDATE sensors SET json=?, updated=? WHERE user_id=?", (json.dumps(latest), time.time(), row["user_id"]))
    db().commit()
    return jsonify(ok=True, stored=latest)


@app.get("/api/health")
def health():
    return jsonify(ok=True, auth=True)


@app.get("/api/climate")
def climate():
    try:
        # Privacy: snap to the ~0.5° NASA POWER grid, so the exact field location is never sent to NASA
        lat = round(float(request.args["lat"]) * 2) / 2
        lon = round(float(request.args["lon"]) * 2) / 2
        if not (-90 <= lat <= 90 and -180 <= lon <= 180):
            raise ValueError
    except (KeyError, ValueError):
        return jsonify(code="badCoords", error="Provide valid lat and lon."), 400
    try:
        p = fetch_power_daily(lat, lon, BASELINE[0], RECENT[1])
    except (requests.RequestException, KeyError, ValueError):
        try:  # fall back to the much smaller monthly request
            pm = fetch_power_monthly(lat, lon, BASELINE[0], RECENT[1])
            base, recent = monthly_from_monthly(pm, BASELINE), monthly_from_monthly(pm, RECENT)
            if None in base["tmax"] or None in recent["tmax"]:
                raise ValueError("incomplete record")
            return jsonify(lat=lat, lon=lon, source="NASA POWER monthly (T2M_MAX, PRECTOTCORR, GWETROOT), community=AG",
                           base=base, recent=recent)
        except (requests.RequestException, KeyError, ValueError) as e:
            return jsonify(code="nasaFail", error=f"NASA POWER request failed: {e}"), 502
    return jsonify(
        lat=lat,
        lon=lon,
        source="NASA POWER daily (T2M_MAX, PRECTOTCORR), community=AG",
        base=monthly_climatology(p, BASELINE),
        recent=monthly_climatology(p, RECENT),
        exact_heat_days_above_35={
            MONTHS[m - 1]: [heat_days(p, BASELINE, [m], 35), heat_days(p, RECENT, [m], 35)] for m in range(1, 13)
        },
    )


SOILGRIDS = "https://rest.isric.org/soilgrids/v2.0/properties/query"


def classify_soil(sand: float, clay: float, soc_gkg: float, ph: float) -> dict:
    """Map SoilGrids topsoil values to FieldShift's simple soil inputs."""
    texture = "sandy" if sand >= 60 and clay < 15 else "clay" if clay >= 35 else "loam"
    om_pct = soc_gkg / 10 * 1.72  # organic carbon g/kg -> % organic matter (van Bemmelen factor)
    om = "low" if om_pct < 1 else "high" if om_pct > 3 else "medium"
    return {"texture": texture, "om": om, "ph": round(ph, 1), "om_pct": round(om_pct, 2)}


@app.get("/api/soil")
def soil():
    """Topsoil (0-30 cm) pH, texture and organic carbon from ISRIC SoilGrids 2.0."""
    try:
        # Privacy: ~1 km rounding is enough for SoilGrids' 250 m maps to describe the area, not the exact field
        lat, lon = round(float(request.args["lat"]), 2), round(float(request.args["lon"]), 2)
        r = requests.get(SOILGRIDS, timeout=45, params=[("lat", lat), ("lon", lon), ("value", "mean"),
            *[("property", p) for p in ("phh2o", "sand", "clay", "soc")],
            *[("depth", d) for d in ("0-5cm", "5-15cm", "15-30cm")]])
        r.raise_for_status()
        vals = {}
        for layer in r.json()["properties"]["layers"]:
            d = layer["unit_measure"]["d_factor"]
            v = [x["values"]["mean"] for x in layer["depths"] if x["values"]["mean"] is not None]
            vals[layer["name"]] = sum(v) / len(v) / d if v else None
        # SoilGrids units after d_factor: pH, sand/clay %, soc g/kg
        if None in (vals.get("phh2o"), vals.get("sand"), vals.get("clay"), vals.get("soc")):
            return jsonify(error="No SoilGrids data here (water, urban or rock?)."), 404
        return jsonify(source="ISRIC SoilGrids 2.0", **classify_soil(vals["sand"], vals["clay"], vals["soc"], vals["phh2o"]))
    except (KeyError, ValueError):
        return jsonify(error="Provide valid lat and lon."), 400
    except requests.RequestException as e:
        return jsonify(error=f"SoilGrids request failed: {e}"), 502


@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
