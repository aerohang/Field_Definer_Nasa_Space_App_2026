"""Offline tests: synthetic NASA POWER-shaped data, no network needed.  Run: python -m pytest -q"""
import datetime as dt
import os
import tempfile

os.environ["FIELDSHIFT_DATA"] = tempfile.mkdtemp()  # isolated test database
import app as fs

fs.RECENT = (2010, 2024)  # pin the recent window for deterministic tests


def synthetic(start=1991, end=2024, warming=1.0):
    T, P = {}, {}
    d = dt.date(start, 1, 1)
    while d.year <= end:
        k = d.strftime("%Y%m%d")
        T[k] = 30 + (warming if d.year >= 2010 else 0)
        P[k] = 10.0 if d.month == 7 else 0.0
        d += dt.timedelta(days=1)
    T["19910101"] = -999  # fill value must be ignored
    G = {k: (0.3 if k >= "2010" else 0.4) for k in T}
    return {"T2M_MAX": T, "PRECTOTCORR": P, "GWETROOT": G}


def test_monthly_climatology_shift():
    p = synthetic()
    b = fs.monthly_climatology(p, fs.BASELINE)
    r = fs.monthly_climatology(p, fs.RECENT)
    assert b["tmax"][0] == 30.0 and r["tmax"][0] == 31.0  # synthetic data warms from 2010 onward
    assert b["rain"][6] == 310 and b["rain"][0] == 0


def test_heat_days():
    p = synthetic(warming=1.0)
    assert fs.heat_days(p, fs.BASELINE, [2, 3], 30.5) == 0
    assert 58 <= fs.heat_days(p, fs.RECENT, [2, 3], 30.5) <= 60


def test_api_validation():
    c = fs.app.test_client()
    assert c.get("/api/health").json == {"ok": True, "auth": True}
    assert c.get("/api/climate?lat=999&lon=0").status_code == 400


def test_root_zone_wetness():
    p = synthetic()
    assert fs.monthly_climatology(p, fs.BASELINE)["wet"][5] == 0.4
    assert fs.monthly_climatology(p, fs.RECENT)["wet"][5] == 0.3


def test_soil_classes():
    assert fs.classify_soil(70, 8, 4, 6.5)["texture"] == "sandy"
    assert fs.classify_soil(20, 45, 12, 7.9) == {"texture": "clay", "om": "medium", "ph": 7.9, "om_pct": 2.06}
    assert fs.classify_soil(40, 20, 25, 6.0)["om"] == "high"


def test_static_files_served():
    c = fs.app.test_client()
    assert c.get("/engine.js").status_code == 200 and c.get("/regions.js").status_code == 200
    assert b"FieldShift" in c.get("/").data


def test_accounts_and_state():
    c = fs.app.test_client()
    assert c.post("/api/register", json={"phone": "98765", "pin": "1234", "name": "A", "role": "farmer"}).json["code"] == "badPhone"
    assert c.post("/api/register", json={"phone": "9876543210", "pin": "12", "name": "A", "role": "farmer"}).json["code"] == "badPin"
    r = c.post("/api/register", json={"phone": "+91 98765 43210", "pin": "1234", "name": "Ramesh", "role": "farmer"})
    assert r.status_code == 200 and r.json["user"]["phone"] == "919876543210"
    assert c.post("/api/register", json={"phone": "919876543210", "pin": "9999", "name": "X", "role": "farmer"}).status_code == 409
    assert c.put("/api/state", json={"state": {"farms": [{"name": "Ramesh"}]}}).json == {"ok": True}
    c.post("/api/logout")
    assert c.get("/api/me").status_code == 401
    assert c.put("/api/state", json={"state": {}}).status_code == 401
    ok = c.post("/api/login", json={"phone": "919876543210", "pin": "1234"})
    assert ok.status_code == 200 and ok.json["state"]["farms"][0]["name"] == "Ramesh"
    assert c.get("/api/me").json["user"]["name"] == "Ramesh"


def test_pin_hashed_and_lockout():
    c = fs.app.test_client()
    c.post("/api/register", json={"phone": "254700000001", "pin": "4321", "name": "Wanjiru", "role": "farmer"})
    with fs.app.app_context():
        row = fs.db().execute("SELECT pin_hash FROM users WHERE phone='254700000001'").fetchone()
        assert "4321" not in row["pin_hash"]
    codes = [c.post("/api/login", json={"phone": "254700000001", "pin": "0000"}).json["code"] for _ in range(5)]
    assert codes[:4] == ["wrongPin"] * 4 and codes[4] == "locked"
    assert c.post("/api/login", json={"phone": "254700000001", "pin": "4321"}).json["code"] == "locked"
    assert c.post("/api/login", json={"phone": "999999999999", "pin": "1234"}).json["code"] == "wrongPin"


def test_sensor_device_push():
    c = fs.app.test_client()
    c.post("/api/register", json={"phone": "919000000002", "pin": "2468", "name": "Sunita", "role": "farmer"})
    key = c.get("/api/sensor").json["key"]
    assert c.get("/api/sensor").json["latest"] is None
    device = fs.app.test_client()  # a device has no login, only the key
    assert device.post("/api/sensor/wrong-key", json={"moist": 20}).status_code == 404
    assert device.post(f"/api/sensor/{key}", json={"moist": 500, "ph": "x"}).json["code"] == "noValidReading"
    assert device.post(f"/api/sensor/{key}", json={"moist": 21.4, "ph": 7.2, "rain": 10}).status_code == 200
    device.post(f"/api/sensor/{key}", json={"moist": 19.0, "rain": 5})
    assert c.get("/api/sensor").json["latest"] == {"moist": 19.0, "ph": 7.2, "rain": 15.0}
    assert device.get("/api/sensor").status_code == 401


def test_monthly_fallback_parsing():
    p = {"T2M_MAX": {}, "PRECTOTCORR": {}, "GWETROOT": {}}
    for y in range(1991, 2025):
        for m in range(1, 14):
            k = f"{y}{m:02d}"
            p["T2M_MAX"][k] = 30.0 + (1 if y >= 2010 else 0)
            p["PRECTOTCORR"][k] = 2.0 if m == 1 else 0.0
            p["GWETROOT"][k] = 0.5
    b = fs.monthly_from_monthly(p, fs.BASELINE)
    r = fs.monthly_from_monthly(p, fs.RECENT)
    assert b["tmax"][0] == 30.0 and r["tmax"][0] == 31.0
    assert b["rain"][0] == 62 and b["rain"][1] == 0
    assert b["wet"][5] == 0.5 and len(b["tmax"]) == 12
